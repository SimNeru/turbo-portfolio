package b_Controller;

import java.util.ArrayList;

import a_colori.Colore;
import b_Model.Automobile;
import b_Model.Marca;
import b_Model.Modello;
import b_Model.Modello_Honda;

public class AutosaloneCTRL {

	private ArrayList<Automobile> autoDisponibili = new ArrayList<Automobile>();
	private String nomeAutoSalone;
	
	public AutosaloneCTRL(String nomeAutoSalone) {
		this.nomeAutoSalone = nomeAutoSalone;
		autoDisponibili.add(new Automobile(Colore.ORANGE, Modello.CIVIC, Marca.HONDA, 1400));
		autoDisponibili.add(new Automobile(Colore.GREEN, Modello.M3, Marca.BMW, 4000));
	}
	
	public void addAuto() 
	{
		Automobile nuovaAuto = new Automobile();
		
		nuovaAuto.setMarca(Marca.HONDA);
		
		if(nuovaAuto.getMarca().equals("HONDA")) 
		{
			nuovaAuto.setModello(Modello_Honda.CIVIC);
		}
	}
	
}
