package b_Model;

public enum Modello {

	CHR, CIVIC, M3, M128, GLC;
}
