package b_Model;

import a_colori.Colore;

public class Automobile {

	private Colore colore;
	private Modello modello;
	private Marca marca;
	private int cilindrata;
	
	public Automobile() {
	}

	public Automobile(Colore colore, Modello modello, Marca marca, int cilindrata) {
		this.colore = colore;
		this.modello = modello;
		this.marca = marca;
		this.cilindrata = cilindrata;
	}

	public Colore getColore() {
		return colore;
	}

	public Modello getModello() {
		return modello;
	}

	public Marca getMarca() {
		return marca;
	}

	public int getCilindrata() {
		return cilindrata;
	}

	@Override
	public String toString() {
		return "Automobile [colore=" + colore + ", modello=" + modello + ", marca=" + marca + ", cilindrata="
				+ cilindrata + "]";
	}

	public void setMarca(Marca marca) {
		this.marca = marca;
	}
	
	public void setModello(Modello_Honda modelloHonda) 
	{
		this.modello = modello;
	}
	
}
