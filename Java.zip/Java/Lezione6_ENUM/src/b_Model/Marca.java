package b_Model;

public enum Marca {
	
	TOYOTA ("Toyota"),
	HONDA ("Honda"),
	BMW ("Bmw"),
	FIAT ("Fiat"),
	MERCEDES ("Mercedes");

	String nomeMarca;
	
	private Marca(String nomeMarca) {
		this.nomeMarca = nomeMarca;
	}
	
	public void setModello(String nomeMarca) {
		this.nomeMarca = nomeMarca;
	}

	public String getModello() 
	{
		return this.nomeMarca;
	}
	
	public Modello_Honda getModelloHonda() 
	{
		Modello_Honda md_h = Modello_Honda.CIVIC;
		return md_h;
	};

}


