package b_Model;

public enum Modello_Honda {

	CIVIC, JAZZ, S2000
}
