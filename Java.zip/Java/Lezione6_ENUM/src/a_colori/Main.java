package a_colori;

public class Main {

	public static void main(String[] args) {
		
		Colore primoColore = Colore.ORANGE;
		System.out.println(primoColore.getNomeIta());

		switch (primoColore) {
		case BLACK:
			System.out.println("Hai scelto il colore NERO! " + primoColore.getIndex());
			break;
		case BLUE:
			System.out.println("Hai scelto il colore BLU! " + primoColore.getIndex());
			break;
		case GREEN:
			System.out.println("Hai scelto il colore VERDE! " + primoColore.getIndex());
			break;
		case RED:
			System.out.println("Hai scelto il colore ROSSO! " + primoColore.getIndex());
			break;
		case YELLOW:
			System.out.println("Hai scelto il colore GIALLO! " + primoColore.getIndex());
			break;
		case ORANGE:
			System.out.println("Hai scelto il colore ARANCIONE! " + primoColore.getIndex());
			break;
		default:
			throw new IllegalArgumentException("Unexpected value " + primoColore);
		}
	}

}
