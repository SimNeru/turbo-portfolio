package a_colori;

public enum Colore {

	BLUE ("Blu", 1), 
	GREEN ("Verde", 2), 
	RED ("Rosso", 3), 
	YELLOW ("Giallo", 4), 
	BLACK ("Nero", 5), 
	ORANGE ("Arancione", 6);
	
	private String nomeIta;
	private int index;

	private Colore(String nomeIta,int index) {
		this.nomeIta = nomeIta;
		this.index = index;
	}	
	
	public String getNomeIta() 
	{
		return nomeIta;
	}
	
	public int getIndex() 
	{
		return index;
	}
}