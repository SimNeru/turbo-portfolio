package a_eccezioni;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Main {

	public static void main(String[] args){

		File f = new File("./test.txt");
		f.exists();
		
		// Richiederà di essere gestita come eccezione se non inserito in try catch
		// oppure che la classe implementi throwable
		try {
			FileReader fr = new FileReader(f);
		} catch (FileNotFoundException e) {
			System.out.println("Il file non è stato trovato");
//			e.printStackTrace();
		}
		
		stampaTesto("Ciao");
		// se passo testo null si spacca
		stampaTesto(null);
		
		stampaTesto2("Simo");
		stampaTesto2(null);
		
		// richiede di essere wrappato nel try catch perché lancia un'eccezione
		try {
			stampaTesto3("Simo");
		} catch (MieEccezioni e) {
			System.out.println(e.getMessage());
		}
		
		// try catch gestito nel metodo esegui
		esegui(null);
		
		int[] intArray = {1,67,45,34,25}; // 0-4
		
		// try catch dell'inserimento di valori in un array statico
		try {
			addValueArrayStatic(intArray, 5, 100);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		for (int i : intArray) {
			System.out.println(i);
		}
		
		// try catch della divisione
		divide(4,0);
	}

	private static void stampaTesto(String testo) 
	{
		if (testo != null) 
		{
			String tmp = testo.concat("...");
			System.out.println(tmp);
		} else {
			System.out.println("Non puoi avere testo null");
		}
	}
	
	private static void stampaTesto2(String testo) 
	{
		try {
			String tmp = testo.concat("...");
			System.out.println(tmp);
			
			int val = 10;
			if (testo != null && testo.length() < val) {
				System.out.println("il tuo testo ha meno di " + val + " caratteri");
			}
			
		} catch (IndexOutOfBoundsException e) {
			System.out.println("Siamo nella IOB --- CATCH");
//			e.printStackTrace();
		} catch (NullPointerException e) {
			System.out.println("Siamo nella null pointer exception --- CATCH");
//			e.printStackTrace();
		}finally {
			// il finally viene eseguito SEMPRE al termine del blocco sopra
			System.out.println("Sto eseguendo il finally ♫");
		}
	}
	
	// throws demanda gestione eccezione richiedente
	private static void stampaTesto3(String testo) throws MieEccezioni
	{
		if(testo==null) 
		{
			throw new MieEccezioni();
		} else 
		{
			String tmp = testo.concat("...");
			System.out.println(tmp);
		}
	}

	private static void esegui(String testo) 
	{
		try {
			stampaTesto3(testo);
		} catch (MieEccezioni e) {
			System.out.println(e.getMessage());
		}
	}

	private static int[] addValueArrayStatic(int[] intArray, int index, int value) throws Exception
	{
		try {
			intArray[index] = value;
			return intArray;
		} catch (IndexOutOfBoundsException e) {
			System.out.println("L'int eccede l'index massimo dell'array");
//			e.printStackTrace();
		}
		return intArray;
	}

	private static void divide(double var1, double var2) throws ArithmeticException
	{
		try {
			System.out.println(var1 / var2);
		}
		catch (NullPointerException e) {
			System.out.println("E' presente un null");
		}
		catch (ArithmeticException e) {
			System.out.println("Errore, il var2 è 0");
		}
	}
}

