package com.simeru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutosaloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
