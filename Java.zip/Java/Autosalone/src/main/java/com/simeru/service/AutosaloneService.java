package com.simeru.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simeru.entities.Automobile;
import com.simeru.repository.IAutomobileDAO;

@Service
public class AutosaloneService implements IAutosaloneService{

	@Autowired
	private IAutomobileDAO dao;
	
	@Override
	public List<Automobile> getAutomobili() {
		return dao.findAll();
	}

	@Override
	public List<Automobile> getAutomobiliByMarca(String marca) {
		return dao.findAll();
	}

	@Override
	public List<Automobile> getAutomobiliByPrezzo(double min, double max) {
		return null;
	}

	@Override
	public Automobile getAutomobileById(long id) {
		return dao.getReferenceById(id);
	}

	@Override
	public Automobile addAutoMobile(Automobile a) {
		return dao.save(a);
	}

	@Override
	public Automobile updateAutomobile(Automobile a) {
		return dao.save(a);
	}

	@Override
	public void deleteAutomobile(Automobile a) {
		dao.delete(a);
	}

}
