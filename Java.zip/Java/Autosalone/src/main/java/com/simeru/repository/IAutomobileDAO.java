package com.simeru.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.simeru.entities.Automobile;

public interface IAutomobileDAO extends JpaRepository<Automobile, Long> {

}
