package com.simeru.service;

import java.util.List;

import com.simeru.entities.Automobile;

public interface IAutosaloneService {
	
	List<Automobile> getAutomobili();
	List<Automobile> getAutomobiliByMarca(String marca);
	List<Automobile> getAutomobiliByPrezzo(double min, double max);
	
	Automobile getAutomobileById(long id);
	Automobile addAutoMobile(Automobile a);
	Automobile updateAutomobile(Automobile a);
	void deleteAutomobile(Automobile a);

}
