package rettangolo;

public class Cerchio implements IFiguraGeometrica{

	private double ray;
	private double area;
	private double perimetro;
	
	public Cerchio(double ray) {
		this.ray = ray;
	}

	@Override
	public double calcolaArea() {
		this.area = Math.ceil(Math.PI * Math.pow(ray, 2));
		return this.area;
	}

	@Override
	public double calcolaPerimetro() {
		this.perimetro = Math.ceil(2 * Math.PI * this.ray);
		return this.perimetro;
	}

	@Override
	public String presentaFigura() {
		return "Sono un CERCHIO: \nArea = " + this.area + "\nPerimetro = " + this.perimetro;
	}

}
