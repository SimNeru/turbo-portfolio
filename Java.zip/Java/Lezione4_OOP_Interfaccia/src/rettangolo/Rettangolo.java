package rettangolo;

public class Rettangolo implements IFiguraGeometrica {
	
	private double lato1;
	private double lato2;
	protected double area;
	protected double perimetro;
	
	public Rettangolo(double lato1, double lato2) {
		this.lato1 = lato1;
		this.lato2 = lato2;
	}
	
	@Override
	public double calcolaArea() {
		this.area = Math.ceil(this.lato1 * this.lato2);
		return this.area;
	}
	
	@Override
	public double calcolaPerimetro() {
		this.perimetro = Math.ceil(2 * (this.lato1 + this.lato2));
		return this.perimetro;
	}
	
	@Override
	public String presentaFigura() {
		return "Sono un RETTANGOLO: \nArea = " + this.area + "\nPerimetro = " + this.perimetro;
	}
	
}
