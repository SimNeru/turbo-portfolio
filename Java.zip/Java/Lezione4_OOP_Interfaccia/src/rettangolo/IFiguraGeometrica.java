package rettangolo;

public interface IFiguraGeometrica {

	// qui vado a definire i comportamenti comuni a tutte le classi che implementeranno la mia interfaccia
	double calcolaArea();
	double calcolaPerimetro();
	String presentaFigura();
	
}
