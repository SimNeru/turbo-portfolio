package rettangolo;

public class Main {

	public static void main(String[] args) {

		Rettangolo rettangolo = new Rettangolo(5.3, 7.1);
		rettangolo.calcolaPerimetro();
		rettangolo.calcolaArea();
		System.out.println(rettangolo.presentaFigura()+ "\n");
		
		Cerchio cerchio = new Cerchio(5);
		cerchio.calcolaPerimetro();
		cerchio.calcolaArea();
		System.out.println(cerchio.presentaFigura()+ "\n");
		
		Quadrato quadrato = new Quadrato(12);
		quadrato.calcolaPerimetro();
		quadrato.calcolaArea();
		System.out.println(quadrato.presentaFigura()+ "\n");
		
		Triangolo triangolo = new Triangolo(8,10,50);
		triangolo.calcolaPerimetro();
		triangolo.calcolaArea();
		System.out.println(triangolo.presentaFigura()+ "\n");
	}

}