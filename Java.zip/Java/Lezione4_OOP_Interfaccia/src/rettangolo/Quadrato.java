package rettangolo;

public class Quadrato extends Rettangolo{

	private double lato;
	
	public Quadrato(double lato) {
		super(lato, lato);
		this.lato = lato;
	}

	@Override
	public String presentaFigura() {
		return "Sono un QUADRATO: \nArea = " + super.area + "\nPerimetro = " + super.perimetro;
	}

	
}
