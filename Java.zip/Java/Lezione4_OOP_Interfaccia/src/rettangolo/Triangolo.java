package rettangolo;

public class Triangolo implements IFiguraGeometrica {

	private double lato1;
	private double lato2;
	private double lato3;
	private double area;
	private double perimetro;
	
	/* Per verificare se un insieme di tre segmenti può formare un triangolo, si devono soddisfare le seguenti condizioni:
	 * La somma di due lati qualsiasi deve essere maggiore del terzo lato.
	 * La differenza tra due lati qualsiasi deve essere minore del terzo lato. */
	
	public Triangolo(double lato1, double lato2, double lato3) {
		super();
		this.lato1 = lato1;
		this.lato2 = lato2;
		this.lato3 = lato3;
		
		if(lato1+lato2>lato3) 
		{
			if(lato1+lato3>lato2) 
			{
				if(lato3+lato2>lato1)
				{
					System.out.println("Triangolo esistente");
				} else {System.out.println("NON ESISTENTE");}
			} else {System.out.println("NON ESISTENTE");}
		} else {System.out.println("NON ESISTENTE");}
	}

	@Override
	public double calcolaArea() {
		double semiP = this.perimetro / 2;
		this.area = Math.ceil(Math.sqrt(semiP * (semiP - lato1) * (semiP - lato2) * (semiP - lato3)));
		return this.area;
	}

	@Override
	public double calcolaPerimetro() {
		this.perimetro = lato1 + lato2 + lato3;
		return this.perimetro;
	}

	@Override
	public String presentaFigura() {
		return "Sono un TRIANGOLO: \nArea = " + this.area + "\nPerimetro = " + this.perimetro;
	}

}
