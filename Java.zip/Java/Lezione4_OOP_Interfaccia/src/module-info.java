/**
 * 
 */
/**
 * 
 */
module Lezione4_OOP_Interfaccia {
}