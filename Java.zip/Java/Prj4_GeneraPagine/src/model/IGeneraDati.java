package model;

public interface IGeneraDati {

	public String generaHTML();
	
	public String generaXML();
	
	public String generaJSON();
	
	public String generaTXT();
	
}
