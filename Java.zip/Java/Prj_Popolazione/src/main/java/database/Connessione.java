package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connessione {

	private final String URL = "jdbc:mysql://localhost:3306/java_backend";
	private final String USER = "app_goal";
	private final String PASSWORD = "goal_2024!";
	
	private Connection conn;
	
	public Connection getConn() 
	{
		if (conn == null) connetti();
		return conn;
	}
	
	// ho bisogno di inizializzare il driver scaricato per assegnarlo alla variabile di riferimento conn
	private void connetti() {
		// driverManager ha un metodo che se gli passi i parametri definiti proverà a stabilire uan connessione		
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("SEI CONNESSO");
		} catch (SQLException e) {
			System.err.print("NON SEI CONNESSO" + e.getMessage());
		}
	}
	
	// DAO (Data Access Object) 
	
}
