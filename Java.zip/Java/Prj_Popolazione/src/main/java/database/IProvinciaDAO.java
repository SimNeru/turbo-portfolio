package database;

import java.util.List;

import model.Provincia;

public interface IProvinciaDAO {

	String FIND_ALL = "Select * from popolazione_italiana_regione";
	
	List<String> getRegioni();
	List<Provincia> getProvinceByRegione(String regione);
	Provincia getProvinciaById(int id);
}
