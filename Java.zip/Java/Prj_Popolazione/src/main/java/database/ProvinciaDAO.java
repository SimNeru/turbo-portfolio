package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Provincia;

public class ProvinciaDAO implements IProvinciaDAO {

	private Connessione cn;
	private Statement st;
	private ResultSet rs;
	
	private List<Provincia> provinceList;
	private Map<Integer, Provincia> provinceMap;
	
	public ProvinciaDAO() {
		cn = new Connessione();
		provinceList = new ArrayList<Provincia>();
		provinceMap = new HashMap<Integer, Provincia>();
		init();
	}
	
	private void init(){
		try {
			st = cn.getConn().createStatement();
			rs = st.executeQuery(FIND_ALL);
			while(rs.next()) 
			{
				Provincia p = new Provincia();
				p.setId(rs.getInt("id"));
				p.setNome(rs.getString("comune"));
				p.setFemmine(rs.getInt("femmine"));
				p.setMaschi(rs.getInt("maschi"));
				p.setRegione(rs.getString("regione"));
				p.setTotale(rs.getInt("totale"));
				provinceList.add(p);
				provinceMap.put(p.getId(),p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public List<String> getRegioni() {
		
		return provinceList.stream()
				.map( p -> p.getRegione())
				.distinct()
				.sorted()
				.toList();
	}

	@Override
	public List<Provincia> getProvinceByRegione(String regione) {
		return provinceList
				.stream()
				.filter( p -> p.getRegione().equals(regione))
				.toList();
	}

	@Override
	public Provincia getProvinciaById(int id) {
		
//		return provinceList
//				.stream()
//				.filter( p -> p.getId() == id)
//				.toList()
//				.get(0);
		
		return provinceMap.get(id);
	}

}
