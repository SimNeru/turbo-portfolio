package com.prjboats.model;

public class Barca {
	
	private static int counter = 1;
	private int id;
	private String tipologia;
	private String statoNoleggio;
	private String descrizione;
	
	public Barca(String tipologia, String statoNoleggio, String descrizione) {
		this.id = counter++;
		this.tipologia = tipologia;
		
				if (statoNoleggio.equals(null)) 
				{
					this.statoNoleggio = "si";
				} else 
				{
					this.statoNoleggio = statoNoleggio;
				}
				
		this.descrizione = descrizione;
	}

	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	public String getStatoNoleggio() {
		return statoNoleggio;
	}

	public void setNoleggioSI() {
		this.statoNoleggio = "si";
	}
	
	public void setNoleggioNO() {
		this.statoNoleggio = "no";
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	@Override
	public String toString() {
		return "Barca [id=" + id + ", tipologia=" + tipologia + ", statoNoleggio=" + statoNoleggio + ", descrizione="
				+ descrizione + "]";
	}

}
