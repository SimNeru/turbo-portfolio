package com.prjboats.controller;

import java.util.List;
import java.util.Scanner;

import com.prjboats.db.BarcaDAO;
import com.prjboats.model.Barca;

public class AgenziaNoleggioBarche {
	
	BarcaDAO barcaDAO;
	
	public AgenziaNoleggioBarche() 
	{
		barcaDAO = new BarcaDAO();
	}
	
	public void addBarcaToDB() 
	{
		System.out.println("Inserisci una nuova barca su db:");
		Scanner sc = new Scanner(System.in);
		System.out.println("Digita tipologia..");
		String tipologia = sc.nextLine();
		System.out.println("Digita stato Noleggio..");
		String statoNoleggio = sc.nextLine();
		System.out.println("Digita dettagli..");
		String dettagli = sc.nextLine();
		Barca barca = new Barca(tipologia, statoNoleggio, dettagli);
		barcaDAO.addBarcaToDB(barca);
	}
	
	public void printAllBarcheFromDB()
	{
		List<Barca> listaBarche = barcaDAO.getAllBarcaFromDB();
		for (Barca barca : listaBarche) {
			System.out.println(barca);
		}
	}

	public void deleteAllBarcheOnDB() {
		barcaDAO.deleteAllBarcheOnDB();
	}

	public void addDefaultListOnDB() {
		barcaDAO.addDefaultListOnDB();
	}
	
}
