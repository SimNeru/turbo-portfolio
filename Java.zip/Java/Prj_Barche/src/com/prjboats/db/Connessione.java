package com.prjboats.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connessione {
	
	private final String URL = "jdbc:mysql://localhost:3306/java_backend";
	private final String USER = "app_goal";
	private final String PASSWORD = "goal_2024!";

	private Connection cn;
	
	public void connetti() 
	{
		try {
			cn = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("Connessione stabilita");
		} catch (SQLException e) {
			System.out.println("Errore di connessione");
			e.printStackTrace();
		}
	}
	
	public Connection getConn() 
	{
		if (cn==null) {
			connetti();
		}
		return cn;
	}

}
