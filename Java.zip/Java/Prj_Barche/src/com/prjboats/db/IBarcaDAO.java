package com.prjboats.db;

import java.util.List;

import com.prjboats.model.Barca;

public interface IBarcaDAO {

	final String FIND_ALL = "Select * from barche";
	final String ADD = "Insert into barche (tipologia, noleggioStato, dettagli) values (?,?,?)";
	final String DELETE_ALL = "DELETE FROM barche";
	final String INSERT_DEFAULT_BOATS_LIST = "INSERT INTO barche (tipologia, noleggioStato, dettagli) values ('Riva', 'no', 'dettagli'), ('Tullio Abbate', 'si', 'dettagli'), ('Sessa Marine', 'no', 'dettagli'), ('Absolute Yatch', 'no', 'dettagli'), ('Invictus', 'si', 'dettagli');";
	
	void addBarcaToDB(Barca barca);
	List<Barca> getAllBarcaFromDB();
	
}
 