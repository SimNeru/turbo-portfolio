package com.prjboats.db;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.prjboats.model.Barca;

public class BarcaDAO implements IBarcaDAO{
	
	private Connessione myConn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	List<Barca> barche = new ArrayList<Barca>();

	public BarcaDAO() 
	{
		myConn = new Connessione();
	}
	
	@Override
	public void addBarcaToDB(Barca barca) {
		try {
			ps = myConn.getConn().prepareStatement(ADD);
			ps.setString(1, barca.getTipologia());
			ps.setString(2, barca.getStatoNoleggio());
			ps.setString(3, barca.getDescrizione());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Barca> getAllBarcaFromDB() {
		try {
			ps = myConn.getConn().prepareStatement(FIND_ALL);
			rs = ps.executeQuery();
			
			while(rs.next()) 
			{
				String tipologia = rs.getString("tipologia");
				String noleggioStato = rs.getString("noleggioStato");
				String descrizione = rs.getString("dettagli");
				Barca barca = new Barca(tipologia,noleggioStato,descrizione);
				barche.add(barca);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return barche;
	}

	public void deleteAllBarcheOnDB() {
		try {
			ps = myConn.getConn().prepareStatement(DELETE_ALL);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void addDefaultListOnDB() {
		try {
			ps = myConn.getConn().prepareStatement(INSERT_DEFAULT_BOATS_LIST);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
