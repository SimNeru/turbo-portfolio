package com.prjboats.view;

import com.prjboats.controller.AgenziaNoleggioBarche;

public class Main {

	public static void main(String[] args) {

		AgenziaNoleggioBarche agenzia = new AgenziaNoleggioBarche();
		
		agenzia.addDefaultListOnDB();
		
//		agenzia.addBarcaToDB();
		
		agenzia.printAllBarcheFromDB();
		
//		agenzia.deleteAllBarcheOnDB();
	}
	
}
