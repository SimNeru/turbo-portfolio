package com.simeru.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.simeru.entities.TVSeries;

@Repository
public interface ITVSeriesDAO extends JpaRepository<TVSeries, Integer>{

}
