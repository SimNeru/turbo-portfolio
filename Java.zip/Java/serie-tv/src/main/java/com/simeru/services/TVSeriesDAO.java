package com.simeru.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simeru.entities.TVSeries;
import com.simeru.repositories.ITVSeriesDAO;

@Service
public class TVSeriesDAO implements TVSerieService {

	@Autowired
	private ITVSeriesDAO dao;
	
	@Override
	public List<TVSeries> getSeries() {
		return dao.findAll();
	}

	@Override
	public TVSeries getSerieByID(int id) {
		return dao.getReferenceById(id);
	}

	@Override
	public TVSeries addSerieTV(TVSeries tvs) {
		return dao.save(tvs);
	}
	
	

}
