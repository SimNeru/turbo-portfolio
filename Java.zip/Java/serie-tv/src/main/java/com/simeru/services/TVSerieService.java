package com.simeru.services;
import java.util.List;
import org.springframework.stereotype.Service;
import com.simeru.entities.TVSeries;

@Service
public interface TVSerieService {

	List<TVSeries> getSeries();
	TVSeries getSerieByID(int id);
	TVSeries addSerieTV(TVSeries tvs);
	
}
