package com.simeru.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.simeru.entities.TVSeries;
import com.simeru.services.TVSerieService;

@RestController
@RequestMapping("api")
public class TVSeriesREST {

	@Autowired
	private TVSerieService service;
	
	@GetMapping("series")
	public List<TVSeries> getTVSeries()
	{
		return service.getSeries();
	}
	
//	@GetMapping("series")
	public TVSeries getSeriesByID(int id) 
	{
		return service.getSerieByID(id);
	}
	
	@PostMapping("series")
	public TVSeries addSeries(@RequestBody TVSeries tvs) 
	{
		return service.addSerieTV(tvs);
	}
	
	
}
