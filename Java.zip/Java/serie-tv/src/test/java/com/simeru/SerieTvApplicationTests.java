package com.simeru;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.simeru.controller.TVSeriesREST;

@SpringBootTest
class SerieTvApplicationTests {
	
	@Autowired
	TVSeriesREST rest;

	@Test
	@Order(1)
	void addSeries() {
		rest.addSeries(null);
	}
	
	@Test
	@Order(2)
	void getSeriesByID() {
		rest.getSeriesByID(1);
	}
	
	@Test
	@Order(3)
	void getSeries() {
		rest.getTVSeries();
	}
	

}
