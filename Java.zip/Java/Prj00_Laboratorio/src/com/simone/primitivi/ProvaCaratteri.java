package com.simone.primitivi;

import java.util.List;

public class ProvaCaratteri {

	public static void main(String[] args) {
		
		// 4 tipi interi
		byte b = 12; // 8 bit
		short s = 12; // 16 bit
		int intero = 12; // 32 bit
		long l = 12l; // 64 bit

		// tipi reali
		float f = 12.0f; // 32
		double d = 12.0d; // 64

		// boolean
		boolean gira = true;

		// tipo char (numeric)
		for (int i = 0; i <= 65535; i++) {
			System.out.println(i +  ": " + (char) i);
			
//			if (i%80 == 0 && i > 0) 
//			{
//				System.out.println(); 
//			}
		}
	}
}
