package com.simone.collezioni;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ProvaListe {

	public static void main(String[] args) {

		String[] naniArr = 
			{
				"Pisolo","Mammolo","Gongolo","Brontolo","Eolo","Dotto","Cucciolo"
			};
		
		List<String> nani = new LinkedList<String>(); // Stack classe last in first out 
		
		for (String nano : naniArr) {
			nani.add(nano);
		}
		
		for (String nano : naniArr) {
			System.out.println(nano);
		}
		
		// java collections framework 
	}
}