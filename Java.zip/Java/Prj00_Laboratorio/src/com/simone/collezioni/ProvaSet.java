package com.simone.collezioni;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.simone.model.Libro;

public class ProvaSet {

	public static void main(String[] args) {

		// Set non garantisce ordinamento
//		Set<String> nomi = new HashSet<String>();
		Set<String> nomi = new TreeSet<String>();
		
		nomi.add("mattias");
		nomi.add("marco");
		nomi.add("denis");
		nomi.add("marco");
		nomi.add("raffaele");
		nomi.add("raffaele");
		nomi.add("raffaele");
		nomi.add("raffaele");
		nomi.add("simone");
		
		// set garantisce che copioni verranno inseriti solo una volta, non è il suo ruolo gestire ordinamento
//		for (String string : nomi) {
//			System.out.println(string);
//		}
		
		Libro l1 = new Libro("zanna bianca", 100, 10);
		Libro l2 = new Libro("manitu", 120, 12);
		Libro l3 = new Libro("albachiara", 140, 8);
		
//		Set<Libro> libri = new HashSet<>();
// 		treeset si romperà perché funziona solo su classi ordinabili
//      sarà richiesto appunto implementare l'interfaccia Comparable sul model in question
		Set<Libro> libri = new TreeSet<>(); // treeset si romperà perché funziona solo su classi ordinabili
		libri.add(l1);
		libri.add(l2);
		libri.add(l3);
		
		for (Libro libro : libri) {
			System.out.println(libro);
		}
	}

}
