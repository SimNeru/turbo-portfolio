package view;

import controller.PokemonCrtl;

public class ProvaPokemon {

	public static void main(String[] args) {
		
		PokemonCrtl controller = new PokemonCrtl();
		
//		controller.getTipiPokemon().forEach(p -> System.out.println(p));
		
		controller.getNomiPokemon().stream().sorted().forEach(p -> System.out.println(p));

	}

}
