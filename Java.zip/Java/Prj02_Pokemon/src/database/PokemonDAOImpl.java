package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import model.Pokemon;

public class PokemonDAOImpl implements PokemonDAO {

	private Connessione conn;
	private Statement istruzionePerDB;
	private ResultSet risultatiDB;
	
	// Creo una mappa di Pokemon
	private Map<Integer, Pokemon> mapPokemon;
	
	public PokemonDAOImpl() 
	{
		conn = new Connessione();
		mapPokemon = new HashMap<Integer, Pokemon>();
		getPokemonMap();
	}
	
	@Override
	public List<Pokemon> getAllPokemon() {
		return new ArrayList<Pokemon>(mapPokemon.values());
	}

	@Override
	public Map<Integer, Pokemon> getPokemonMap() {
		try {
			istruzionePerDB = conn.getConn().createStatement();
			risultatiDB = istruzionePerDB.executeQuery(FIND_ALL);
			
			while(risultatiDB.next()) 
			{
				int id = risultatiDB.getInt(1);
				String name = risultatiDB.getString(2);
				String type1 = risultatiDB.getString(3);
				String type2 = risultatiDB.getString(4);
				
				Pokemon p = new Pokemon(id, name, type1, type2);
				mapPokemon.put(id, p);
			}
		} catch (SQLException e) {
		}
		return null;
	}

	@Override
	public List<Pokemon> getAllPokemonByType(String type) {
		return null;
	}

	@Override
	public Pokemon getPokemonById(int id) {
		return mapPokemon.get(id);
	}

	@Override
	public List<String> getTipiPokemon() {
		Set<String> tipi = new TreeSet<String>();
		for (Pokemon p : getAllPokemon()) {
			tipi.add(p.getType1());
			if(!p.getType2().isEmpty()) 
			{
				tipi.add(p.getType2());
			}
		}
		// passato un set come parametro lo popola di quel tipo
		return new ArrayList<String>(tipi);
	}

}
