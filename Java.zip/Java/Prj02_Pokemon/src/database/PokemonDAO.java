package database;

import java.util.List;
import java.util.Map;

import model.Pokemon;

public interface PokemonDAO {

	String FIND_ALL = "SELECT id, name, `type 1`, `type 2` FROM pokemon";

	List<Pokemon> getAllPokemon();
	Map<Integer, Pokemon> getPokemonMap();
	List<Pokemon> getAllPokemonByType(String type);
	Pokemon getPokemonById(int id);
	List<String> getTipiPokemon();
}
