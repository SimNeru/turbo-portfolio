package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connessione {

	private final String URL = "jdbc:mysql://127.0.0.1:3306/java_backend";
	private final String USER = "app_goal";
	private final String PASSWORD = "goal_2024!";

	private Connection cn = null;

	// lazy initialization
	public Connection getConn() {
		if (cn == null) 
			connetti();
			
			return cn;
	}

	public void connetti() {
		try {
			this.cn = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("Connessione stabilita");
		} catch (SQLException e) {
			System.err.printf("Si è verificato un errore %s", e.getStackTrace());
		}
	}

}
