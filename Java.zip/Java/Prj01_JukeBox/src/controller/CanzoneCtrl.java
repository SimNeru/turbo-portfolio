package controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import model.Canzone;

public class CanzoneCtrl {

	private List<Canzone> canzoni;
	
	public CanzoneCtrl() 
	{
		this.canzoni = new ArrayList<Canzone>();
	}
	
	public void addCanzone(Canzone c) 
	{
		canzoni.add(c);
	}
	
	public void addCanzone(String titolo, String cantante) 
	{
		canzoni.add(new Canzone(titolo,cantante));
	}
	
	public List<Canzone> getCanzoni() {
		return canzoni;
	}
	
	// programmazione procedurale non è obbligatorio input e output 
	// e modifica i risultati esterni
	public List<String> getTitoli() {
		List<String> titoli = new ArrayList<String>();
		for (Canzone canzone : canzoni) {
			titoli.add(canzone.getTitolo());
		}
		return titoli;
	}
	
	// programmazione funzionale, invece di partire da una scatola vuota e di popolarla
	// parte dalla collezione
	public Set<String> getCantanti() {
		// da qui posso filtrare o rimappare la mia collezione
		return new HashSet<String>(
				canzoni.stream()
				.map(c -> c.getCantante())
				.toList());
	}
}
