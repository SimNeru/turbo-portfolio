package view;

import java.io.File;
import java.util.List;
import java.util.Scanner;

import database.CanzoneDAO;
import database.ICanzoneDAO;
import model.Canzone;

public class ProvaScritturaSuDB {

	public static void main(String[] args) {

		ICanzoneDAO dao = new CanzoneDAO();
		
		File f = new File("Z:\\canzoni.txt");
		
//		try {
//				Scanner input = new Scanner(f);
//				
//				while(input.hasNextLine()) 
//				{
//					String riga = input.nextLine();
//					String[] split = riga.split(";");
//					//inserisco ciascun record dal preparedStatement
//					dao.addCanzone(new Canzone(split[0], split[1]));
//				}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
		
		List<Canzone> canzoni = dao.getCanzoni();
		
		for (Canzone canzone : canzoni) {
			System.out.println(canzone);
		}
	
//		Canzone c = new Canzone("sinceramente", "annalisa");
//		Canzone c2 = new Canzone("bum bum", "rose villain");
//		
//		dao.addCanzone(c);
//		dao.addCanzone(c2);
	}

}
