package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Canzone;

public class CanzoneDAO implements ICanzoneDAO{
	
	// query solo la select, ritornano un set di risultati
	// istruzioni di update tutte quelle che modificano tabella 
	
	// connessione al db
	private Connessione miaConn;
	// contenitore istruzioni
	private PreparedStatement ps;
	// contenitori dei risultati
	private ResultSet rs;
	
	List<Canzone> canzoni = new ArrayList<>();

	public CanzoneDAO() {
		miaConn = new Connessione();
	}

	@Override
	public void addCanzone(Canzone c) {
		try {
				ps = miaConn.getConn().prepareStatement(ADD);
				// il metodo cercherà esclusivamente punto interrogativo
				ps.setString(1, c.getTitolo()); // binding collegamento primo param
				ps.setString(2, c.getCantante()); // binding collegamento primo param
				ps.execute(); // esegue la query
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Canzone> getCanzoni() {
		try {
			ps = miaConn.getConn().prepareStatement(FIND_ALL);
			// result set salverà il risultato della query
			rs = ps.executeQuery();
			while(rs.next()) 
			{
				String titolo =	rs.getString("titolo");
				String cantante =	rs.getString("cantante");
				Canzone c = new Canzone(titolo, cantante);
				canzoni.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return canzoni;
	}

}
