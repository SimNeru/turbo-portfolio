package controller;

import java.util.ArrayList;
import java.util.List;

import database.PokemonDAO;
import database.PokemonDAOImpl;
import model.Pokemon;

public class PokemonCtrl {
	
//	private List<Tipi> listaTipi = new ArrayList<>();
	
	private String[] listaTipi = {
			"Normal",
			"Fire",
			"Water",
			"Grass",
			"Electric",
			"Ice",
			"Fighting",
			"Poison",
			"Ground",
			"Flying",
			"Psychic",
			"Bug",
			"Rock",
			"Ghost",
			"Dragon",
			"Dark",
			"Steel",
			"Fairy"};
	
	private PokemonDAO dao = new PokemonDAOImpl();
	
	public List<String> getTipiPokemon()
	{
		return dao.getTipiPokemon();
	}
	
	public List<String> getNomiPokemon(){
		List<String> pokemon = new ArrayList<String>();
		for (Pokemon p : dao.getAllPokemon()) {
			pokemon.add(p.getNome());
		}
		return pokemon;
	}
	
	public String getType(String type) 
	{
		for (String tipo : listaTipi) {
			if(tipo.contains(type)) 
			{
				return tipo;
			}
		}
		return null;
	}
	
	public Pokemon getPokemonByName(String name) 
	{
		Pokemon pokemon = new Pokemon();
		for (Pokemon p : dao.getAllPokemon()) {
			if(p.getNome().equals(name.toLowerCase())) 
			{
				pokemon = p;
				return pokemon;
			}
		}
		return null;
	}
	
	public int weaknessCheck(String type1, String type2) 
	{
		if(type1.equals("Normal")) 
		{
			
		}
		
		return 0;
	}
}
