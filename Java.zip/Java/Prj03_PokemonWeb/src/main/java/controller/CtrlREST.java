package controller;

import java.io.IOException;

import org.json.JSONArray;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/api")
// Si tratta di un servlet e si porta dentro t
public class CtrlREST extends HttpServlet {

	PokemonCtrl controller;
	
	public CtrlREST() 
	{
		
	}
	
	// chiamo override di un metodo contenuto in servlet
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		controller = new PokemonCtrl();
		JSONArray lista = new JSONArray(controller.getNomiPokemon());
		resp.getWriter().print(lista.toString());
	}

}
