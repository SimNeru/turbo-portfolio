package b_Trasporti;

public abstract class Trasporto {

	private static int counter = 1;
	protected int matricola;
	private String origine;
	private String destinazione;
	private String tipologia;
	private String stato;
	
	protected Trasporto() 
	{
		this.matricola = counter++;
		this.tipologia = "DA DEFINIRE";
		this.destinazione = "DA DEFINIRE";
		this.origine = "DA DEFINIRE";
		this.tipologia = "DA DEFINIRE";
		this.stato = "IN PREPARAZIONE";
	}
	
	public abstract String generateRandomMatrice();
	
	@Override
	public String toString() {
		String message = "MATRICOLA: " + this.matricola + "\nORIGINE: " + this.getOrigine() + "\nDESTINAZIONE: " + this.getDestinazione() + "\nTIPOLOGIA: " + getTipologia() + "\nSTATO: " + getStato() + "\nMATRICE: " + generateRandomMatrice();
		return message;
	}
	
	public void consegnato() 
	{
		this.stato = "CONSEGNATO";
	}
	
	public void inConsegna() 
	{
		this.stato = " IN CONSEGNA";
	}

	protected String getOrigine() {
		return origine;
	}

	public void setOrigine(String origine) {
		this.origine = origine;
	}

	protected String getDestinazione() {
		return destinazione;
	}

	public void setDestinazione(String destinazione) {
		this.destinazione = destinazione;
	}

	protected String getTipologia() {
		return tipologia;
	}

	protected void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	protected String getStato() {
		return stato;
	}
	
	
	
}
