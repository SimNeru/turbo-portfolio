package b_Trasporti;

public class Main {
	
	public static void main(String[] args) {
		
		Trasporto nave = new Nave();
		nave.setOrigine("Livorno");
		nave.setDestinazione("New York");
		System.out.println(nave.toString());
		System.out.println();
		
		Trasporto aereo = new Aereo();
		aereo.setOrigine("Roma");
		aereo.setDestinazione("Helsinki");
		aereo.inConsegna();
		System.out.println(aereo.toString());
		System.out.println();
		
		Trasporto treno = new Treno();
		treno.setOrigine("Napoli");
		treno.setDestinazione("Milano");
		treno.consegnato();
		System.out.println(treno.toString());
		System.out.println();
	}

}
