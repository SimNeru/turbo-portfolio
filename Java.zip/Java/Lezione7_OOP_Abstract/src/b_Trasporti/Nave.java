package b_Trasporti;

public class Nave extends Trasporto{

	protected Nave() {
		super();
		setTipologia("NAVALE");
	}

	@Override
	public String generateRandomMatrice() {
		String matrice = "N4V3" + this.matricola;
		return matrice;
	}
	
}
