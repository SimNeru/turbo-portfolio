package b_Trasporti;

public class Aereo extends Trasporto{

	protected Aereo() {
		super();
		setTipologia("AEREA");
	}

	@Override
	public String generateRandomMatrice() {
		String matrice = "A3R30" + this.matricola;
		return matrice;
	}

}
