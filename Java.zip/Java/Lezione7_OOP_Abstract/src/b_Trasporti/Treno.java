package b_Trasporti;

public class Treno extends Trasporto{
	
	private String idTreno;

	protected Treno() {
		super();
		setTipologia("TRENO");
	}

	@Override
	public String generateRandomMatrice() {
		String matrice = "TR3N0" + this.matricola;
		return matrice;
	}
}
