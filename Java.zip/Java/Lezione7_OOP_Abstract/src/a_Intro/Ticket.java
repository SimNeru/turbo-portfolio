package a_Intro;

public abstract class Ticket {

	private int numTicket;
	private String descrizioneProblema;
	private String stato;
	
	public Ticket(int numTicket, String descrizioneProblema) {
		this.numTicket = numTicket;
		this.descrizioneProblema = descrizioneProblema;
		this.stato = "Aperto";
	}
	
	public double calcolaCosti(Double prezzo) 
	{
		return prezzo * 1.22;
	}
	
	public void chiudiTicket() 
	{
		this.stato = "Chiuso";
	}
	
	// quando classe estesa questo metodo dovrà andare in override
	abstract void visualizzaInfo();
	
	public int getNumTicket() {
		return numTicket;
	}

	public void setNumTicket(int numTicket) {
		this.numTicket = numTicket;
	}

	public String getDescrizioneProblema() {
		return descrizioneProblema;
	}

	public void setDescrizioneProblema(String descrizioneProblema) {
		this.descrizioneProblema = descrizioneProblema;
	}

	public String getStato() {
		return stato;
	}

	public void setStato(String stato) {
		this.stato = stato;
	}
	
}
