package a_Intro;

public class TicketHardware extends Ticket{

	private String nomeHardware;
	private double costo;
	
	public TicketHardware(int numTicket, String descrizioneProblema, String nomeHardware, double costo) {
		super(numTicket, descrizioneProblema);
		this.nomeHardware = nomeHardware;
		this.costo = calcolaCosti(costo);
	}

	@Override
	public double calcolaCosti(Double prezzo) {
		return super.calcolaCosti(prezzo);
	}

	@Override
	void visualizzaInfo() {
		System.out.println("Numero Ticket: " + super.getNumTicket());
		System.out.println("Descrizione problema: " + this.getDescrizioneProblema());
		System.out.println("Nome Hardware: " + this.nomeHardware);
		System.out.println("Costo: " + this.costo + "€");
		System.out.println("Stato: " + super.getStato());
	}

}
