package a_Intro;

public class Main {

	public static void main(String[] args) {
		
		int numTick = 22;
		String descrizione = "Lorem Ipsum dolor sit amen";
		String nomeSoft = "Eclipse";

		// creo un ticket software
		TicketSoftware ts = new TicketSoftware(numTick, descrizione, nomeSoft);
		
		numTick = 11;
		descrizione = "Lorem Ipsum dolor sit amen";
		nomeSoft = "Zoom";
		
		Ticket ts1 = new TicketSoftware(numTick, descrizione, nomeSoft);
		
		ts.visualizzaInfo();
		ts.chiudiTicket();
		
		System.out.println();
		ts.visualizzaInfo();
		
		System.out.println();
		ts1.visualizzaInfo();
		
		numTick = 01;
		descrizione = "Lorem Ipsum dolor sit amen";
		String nomeHard = "RAM CORSAIR";
		double prezzo = 129.99;
		
		// creo ticket hardware
		System.out.println();
		Ticket th = new TicketHardware(numTick, descrizione, nomeHard, Math.ceil(prezzo));
		th.chiudiTicket();
		th.visualizzaInfo();
	}

}
