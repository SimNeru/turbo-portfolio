package a_Intro;

public class TicketSoftware extends Ticket{
	
	private String nomeSoftware;
	
	public TicketSoftware(int numTicket, String descrizioneProblema, String nomeSoftware) {
		super(numTicket, descrizioneProblema);
		this.nomeSoftware = nomeSoftware;
	}

	@Override
	void visualizzaInfo() {
		System.out.println("Numero Ticket: " + super.getNumTicket());
		System.out.println("Descrizione problema: " + this.getDescrizioneProblema());
		System.out.println("Nome Software: " + this.nomeSoftware);
		System.out.println("Stato: " + super.getStato());
	}

}
