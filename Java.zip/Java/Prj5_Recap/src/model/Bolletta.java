package model;

public abstract class Bolletta {

	private static long counter = 1;
	private long id;

	private String tipoServizio;
	private String dataScadenza;
	private String intestatario;
	
	public Bolletta(String dataScadenza, String intestatario) {
		this.id = counter++;
		this.dataScadenza = dataScadenza;
		this.intestatario = intestatario;
	}

	abstract double calcoloConsumo();
	
	public long getId() 
	{
		return this.id;
	}

	public String getTipoServizio() {
		return tipoServizio;
	}

	public void setTipoServizio(String tipoServizio) {
		this.tipoServizio = tipoServizio;
	}

	public String getDataScadenza() {
		return dataScadenza;
	}

	public void setDataScadenza(String dataScadenza) {
		this.dataScadenza = dataScadenza;
	}

	public String getIntestatario() {
		return intestatario;
	}

	public void setIntestatario(String intestatario) {
		this.intestatario = intestatario;
	}

	@Override
	public String toString() {
		return "ID: " + id + ", TIPO_SERVIZIO" + tipoServizio + ", DATA_SCADENZA: " + dataScadenza + ", INTESTATARIO: " + intestatario + "]";
	}
		
	
}
