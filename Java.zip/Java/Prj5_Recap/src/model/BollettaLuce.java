package model;

public class BollettaLuce extends Bolletta{

	private double consumoKWH;
	private final double costoEnergia = 0.25;
	
	public BollettaLuce(double consumoKWH, String dataScadenza, String intestatario) {
		super(dataScadenza, intestatario);
		this.consumoKWH = consumoKWH ;
		this.setTipoServizio("LUCE");
	}

	@Override
	public double calcoloConsumo() {
		return Math.ceil(consumoKWH * costoEnergia);
	}

	public String toString() {
		return "ID: " + this.getId() + 
				", TIPO_SERVIZIO: " + this.getTipoServizio() 
				+ ", DATA_SCADENZA: " + this.getDataScadenza() 
				+ ", INTESTATARIO: " + this.getIntestatario() +
				", CONSUMO: " + this.consumoKWH + " KW" + 
				", COSTO_CONSUMO: " + this.calcoloConsumo()+" €";
	}

	public double getConsumoKWH() {
		return consumoKWH;
	}

	public double getCostoEnergia() {
		return costoEnergia;
	}
	
	
}
