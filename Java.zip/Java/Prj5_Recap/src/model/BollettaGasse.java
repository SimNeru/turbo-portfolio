package model;

public class BollettaGasse extends Bolletta{
	
	private double consumoMQ;
	private final double costoMateria = 0.10;

	public BollettaGasse(double consumoMQ ,String dataScadenza, String intestatario) {
		super(dataScadenza, intestatario);
		this.consumoMQ = consumoMQ;
		this.setTipoServizio("GAS");
	}

	@Override
	double calcoloConsumo() {
		double value = Math.ceil(consumoMQ * costoMateria);
		return value;
	}

	@Override
	public String toString() {
		return "ID: " + this.getId() + 
				", TIPO_SERVIZIO: " + this.getTipoServizio() 
				+ ", DATA_SCADENZA: " + this.getDataScadenza() 
				+ ", INTESTATARIO: " + this.getIntestatario() +
				", CONSUMO: " + this.consumoMQ + " MQ" + 
				", COSTO_CONSUMO: " + this.calcoloConsumo()+" €";
	}
}
