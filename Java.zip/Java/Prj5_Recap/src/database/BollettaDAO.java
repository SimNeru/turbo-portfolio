package database;

import java.util.List;

import model.Bolletta;

public interface BollettaDAO {

	String FIND_ALL = "Select * FROM bollette";
	String ADD_BOLL = "INSERT INTO bollette (tipo, consumo, importo, intestatario, dataScadenza) "
			+ "values (?,?,?,?,?)";
	
	List<Bolletta> getAllBollette();
	Bolletta addBolletta(Bolletta bolletta);
	
}


