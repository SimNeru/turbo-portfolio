package database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Bolletta;
import model.BollettaGasse;
import model.BollettaLuce;

public class BollettaDAOimpl implements BollettaDAO{
	
	private Connessione conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	List<Bolletta> listaBollette;
	
	public BollettaDAOimpl() 
	{
		this.conn = new Connessione();
		listaBollette = new ArrayList<>();
	}
	
	public void printAllBollette() 
	{
		getAllBollette();
		for (Bolletta bolletta : this.listaBollette) {
			System.out.println(bolletta);
		}
	}

	@Override
	public List<Bolletta> getAllBollette() {
		try {
			ps = conn.getConn().prepareStatement(FIND_ALL);
			rs = ps.executeQuery();
			while(rs.next()) 
			{
				String tipo = rs.getString("tipo");
				
				if(tipo.toLowerCase().equals("luce")) 
				{
					double consumo = rs.getDouble("consumo");
					String dataScadenza = rs.getString("dataScadenza");
					String intestatario = rs.getString("intestatario"); 
					Bolletta bl = new BollettaLuce(consumo, dataScadenza, intestatario);
					listaBollette.add(bl);
				} else if (tipo.toLowerCase().equals("gas")) 
				{
					double consumo = rs.getDouble("consumo");
					String dataScadenza = rs.getString("dataScadenza");
					String intestatario = rs.getString("intestatario"); 
					Bolletta bg = new BollettaGasse(consumo, dataScadenza, intestatario);
					listaBollette.add(bg);
				} else 
				{
					System.out.println("Not handled case");
				}
			}
		} catch (SQLException e) {
			System.err.printf("Errore restituzione risultati find %s", e.getMessage());
		} 
		return listaBollette;
	}

	@Override
	public Bolletta addBolletta(Bolletta bolletta) {
		// TODO Auto-generated method stub
		return null;
	}

}
