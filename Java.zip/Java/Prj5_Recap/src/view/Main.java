package view;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import database.BollettaDAOimpl;
import database.Connessione;
import model.Bolletta;
import model.BollettaGasse;
import model.BollettaLuce;

public class Main {

	public static void main(String[] args) {
		
//		Bolletta bolletta = new BollettaLuce(35.0, "21/05/2024", "Simone");
//		Bolletta bolletta2 = new BollettaGasse(60.5, "21/05/2024", "Simone");
//		
//		System.out.println(bolletta);
//		System.out.println(bolletta2);

//		Connessione c = new Connessione();
//		c.getConn();
		
		BollettaDAOimpl bdi = new BollettaDAOimpl();
		
		bdi.printAllBollette();
	}
}
