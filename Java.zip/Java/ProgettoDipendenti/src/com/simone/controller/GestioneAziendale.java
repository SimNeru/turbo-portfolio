package com.simone.controller;

import java.util.ArrayList;
import java.util.List;

import com.simone.model.Dipendente;

public class GestioneAziendale {

	private List<Dipendente> listaDipendenti;
	private String nomeAzienda;
	
	public GestioneAziendale(String nomeAzienda) {
		this.nomeAzienda = nomeAzienda;
		this.listaDipendenti = new ArrayList<>();
	}
	
	public void addDipendente(Dipendente dip) 
	{
		this.listaDipendenti.add(dip);
	}

	public List<Dipendente> getListaDipendenti() {
		return listaDipendenti;
	}
	
}
