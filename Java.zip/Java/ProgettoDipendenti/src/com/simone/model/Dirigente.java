package com.simone.model;

public class Dirigente extends Dipendente {

	private double pagaBase = 1_000;
	private int numeroDipendenti;
	private final double quotaDipendenti = 200;
	
	public Dirigente(String nome) {
		super(nome);
		this.ruolo = "dirigente";
	}

	@Override
	public void calcolaStipendio() {
	this.stipendio = pagaBase + (numeroDipendenti*quotaDipendenti);
	}

	public int getNumeroDipendenti() {
		return numeroDipendenti;
	}

	public void setNumeroDipendenti(int numeroDipendenti) {
		this.numeroDipendenti = numeroDipendenti;
	}
	
}
