package com.simone.model;

public abstract class Dipendente {

	private static int counter = 1;
	protected String nome;
	private int matricola;
	protected String ruolo;
	protected double stipendio;
	
	public Dipendente(String nome) 
	{
		this.nome = nome;
		this.matricola = counter++;
	}

	public abstract void calcolaStipendio();

	public double getStipendio() {
		return stipendio;
	}

	@Override
	public String toString() {
		return "Dipendente [nome=" + nome + ", matricola=" + matricola + ", ruolo=" + ruolo + ", stipendio=" + stipendio
				+ "]";
	}

	public String getNome() {
		return this.nome;
	}

	public String getRuolo() {
		return this.ruolo;
	}

}
