package com.simone.model;

public class Impiegato extends Dipendente {

	private int oreLavorate;
	private double pagaBase = 8.5;
	
	public Impiegato(String nome) {
		super(nome);
		this.ruolo = "impiegato";
	}
	
	public int getOreLavorate() {
		return oreLavorate;
	}

	public void setOreLavorate(int oreLavorate) {
		this.oreLavorate = oreLavorate;
	}

	@Override
	public void calcolaStipendio() {
		this.stipendio = oreLavorate * pagaBase;
	}

}
