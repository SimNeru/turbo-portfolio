package com.simone.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.simone.model.Dipendente;

public class DipendenteDAO implements IDipendenteDAO{

	// 
	private Connessione myCon = new Connessione();
	
	// se è una query che eseguisce semplici queryes senza necessità di restituzione
	private PreparedStatement prs;
	
	// se è una query che restituisce risultati
	private ResultSet rs;
	
	@Override
	public void addDipendenteToDB(Dipendente dip) {
		try {
			prs = myCon.getConn().prepareStatement(ADD_DIPENDENTE);
			prs.setString(1, dip.getNome());
			prs.setString(2, dip.getRuolo());
			prs.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Dipendente> getLista() {
		try {
			prs = myCon.getConn().prepareStatement(FIND_ALL);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	
}
