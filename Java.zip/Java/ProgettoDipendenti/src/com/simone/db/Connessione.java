package com.simone.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connessione {

	// definisco le var per accesso db, indirizzo db, user, pass
	private final String URL = "jdbc:mysql://localhost:3306/java_backend";
	private final String USER = "app_goal";
	private final String PASSWORD = "goal_2024!";
	
	// chiamo la reference variable
	private Connection conn;
	
	// costruttore
	public Connection getConn() 
	{
		if (conn == null) connetti();
		return conn;
	}
	
	// definisco il metodo per la logica connessione al db
	private void connetti() {
		try {
			conn = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("SEI CONNESSO");
		} catch (SQLException e) {
			System.err.print("NON SEI CONNESSO" + e.getMessage());
		}
	}
	
	private void disconnetti() 
	{
		if(conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}
