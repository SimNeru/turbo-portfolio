package com.simone.db;

import java.util.List;

import com.simone.model.Dipendente;

public interface IDipendenteDAO {
	
	// Pascal case Maiuscola
	// Camel case minuscola
	// Snake case con_underscore

	String FIND_ALL = "SELECT * FROM dipendenti";
	String ADD_DIPENDENTE = "INSERT INTO dipendenti (nome, ruolo) values (?,?)";
	
	void addDipendenteToDB (Dipendente dip);
	List<Dipendente> getLista();
	
}
