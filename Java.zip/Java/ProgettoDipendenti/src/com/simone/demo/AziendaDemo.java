package com.simone.demo;

import java.util.List;

import com.simone.controller.GestioneAziendale;
import com.simone.db.DipendenteDAO;
import com.simone.db.IDipendenteDAO;
import com.simone.model.Dipendente;
import com.simone.model.Dirigente;
import com.simone.model.Fattorino;
import com.simone.model.Impiegato;

public class AziendaDemo {

	public static void main(String[] args) {
		
		GestioneAziendale azienda1 = new GestioneAziendale("Pippo_Tecnology");
		
		Fattorino f1 = new Fattorino("davide");
		Fattorino f2 = new Fattorino("denis");
		Fattorino f3 = new Fattorino("gianni");
		
		Impiegato i1 = new Impiegato("fabio");
		Impiegato i2 = new Impiegato("enrico");
		Impiegato i3 = new Impiegato("raf");
		
		Dirigente d1 = new Dirigente("simone");
		
		azienda1.addDipendente(f1);
		azienda1.addDipendente(f2);
		azienda1.addDipendente(f3);
		azienda1.addDipendente(i1);
		azienda1.addDipendente(i2);
		azienda1.addDipendente(i3);
		azienda1.addDipendente(d1);
		
		List<Dipendente> listaDipendenti = azienda1.getListaDipendenti();
		for (Dipendente dipendente : listaDipendenti) {
		//	System.out.println(dipendente);
			if(dipendente instanceof Fattorino) 
			{
				((Fattorino) dipendente).setConsegne(100);
			}
			if(dipendente instanceof Impiegato) 
			{
				((Impiegato) dipendente).setOreLavorate(160);
			}
			if(dipendente instanceof Dirigente) 
			{
				((Dirigente) dipendente).setNumeroDipendenti(6);
			}
		}
		
		for (Dipendente dipendente : listaDipendenti) {
			dipendente.calcolaStipendio();
			System.out.println(dipendente);
		}
		
		IDipendenteDAO dao = new DipendenteDAO();
		for (Dipendente dipendente : listaDipendenti) {
			dao.addDipendenteToDB(dipendente);
		}
	}

}
