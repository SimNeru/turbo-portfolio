package com.simeru.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simeru.entities.Country;
import com.simeru.repository.CountryDAO;

@Service
public class CountryServiceImpl implements CountryService{

	@Autowired
	CountryDAO dao;
	
	@Override
	public List<Country> getCountries() {
		return dao.findAll();
	}
	
	@Override
	public Optional<Country> getById(Integer id) {
		return dao.findById(id);
	}

	@Override
	public List<Country> getByCountry(String country) {
		return dao.findByCountry(country);
	}

	@Override
	public List<Country> getByCapital(String capital) {
		return dao.findByCapital(capital);
	}

	@Override
	public List<Country> getByRegion(String region) {
		return dao.findByRegion(region);
	}

	@Override
	public List<Country> getByRegionDistinct() {
		return dao.findByRegionDistinct();
	}

}
