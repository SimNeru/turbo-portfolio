package com.simeru.services;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;

import com.simeru.entities.Country;

public interface CountryService {

	Optional<Country> getById(Integer id);
	List<Country> getByCountry(String country);
	List<Country> getByCapital(String capital);
	List<Country> getByRegion(String region);
	List<Country> getByRegionDistinct();
	List<Country> getCountries();
}
