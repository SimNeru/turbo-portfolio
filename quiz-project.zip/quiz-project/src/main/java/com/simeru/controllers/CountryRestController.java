package com.simeru.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.simeru.entities.Country;
import com.simeru.services.CountryService;

@RestController
@RequestMapping("api")
public class CountryRestController {

	@Autowired
	private CountryService service;
	
	@CrossOrigin
	@GetMapping("countries/easy")
	List<Optional<Country>> getCountriesEasy()
	{
		ArrayList<Integer> generatedInts = new ArrayList<Integer>();
		Random random = new Random();
		Optional<Country> country;
		List<Optional<Country>> generatedList = new ArrayList<>();
		for (int i = 0; i < 3; i++) {
			int idToFetch = random.nextInt(1,171);
			if(generatedInts.contains(idToFetch)) {
				i--;
			} else {
				country = getCountriesByID(idToFetch);
				generatedInts.add(idToFetch);
				generatedList.add(country);
			}
		}
		return generatedList;
	}
	
	@CrossOrigin
	@GetMapping("countries/medium")
	List<Optional<Country>> getCountriesMedium()
	{
		ArrayList<Integer> generatedInts = new ArrayList<Integer>();
		Random random = new Random();
		Optional<Country> country;
		List<Optional<Country>> generatedList = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			int idToFetch = random.nextInt(1,171);
			if(generatedInts.contains(idToFetch)) {
				i--;
			} else {
				country = getCountriesByID(idToFetch);
				generatedInts.add(idToFetch);
				generatedList.add(country);
			}
		}
		return generatedList;
	}
	
	@CrossOrigin
	@GetMapping("countries/hard")
	List<Optional<Country>> getCountriesHard()
	{
		ArrayList<Integer> generatedInts = new ArrayList<Integer>();
		Random random = new Random();
		Optional<Country> country;
		List<Optional<Country>> generatedList = new ArrayList<>();
		for (int i = 0; i < 8; i++) {
			int idToFetch = random.nextInt(1,171);
			if(generatedInts.contains(idToFetch)) {
				i--;
			} else {
				country = getCountriesByID(idToFetch);
				generatedInts.add(idToFetch);
				generatedList.add(country);
			}
		}
		return generatedList;
	}
	
	@GetMapping("countries")
	List<Country> getCountries(){
		return service.getCountries();
	}
	
	@GetMapping("countries/capitals")
	List<String> getCapitals(){
		return service
				.getCountries()
				.stream()
				.map(p -> p.getCapital())
				.distinct()
				.sorted()
				.toList();
	}
	
	@GetMapping("countries/regions")
	List<String> getRegions(){
		return service
				.getCountries()
				.stream()
				.map(p -> p.getRegion())
				.distinct()
				.sorted()
				.toList();
	}
	
	@GetMapping("countries/names")
	List<String> getCountriesName(){
		return service
				.getCountries()
				.stream()
				.map(p -> p.getCountry())
				.distinct()
				.sorted()
				.toList();
	}
	
	@GetMapping("countries/name/{country}")
	List<Country> getCountryByName(@PathVariable String country){
		return service.getByCountry(country);
	}
	
	@GetMapping("countries/capital/{name}")
	List<Country> getCountryByCapital(@PathVariable String name){
		return service.getByCapital(name);
	}
	
	@GetMapping("countries/region/{name}")
	List<Country> getCountryByRegion(@PathVariable String name){
		return service.getByRegion(name);
	}
	
	@GetMapping("countries/id/{id}")
	Optional<Country> getCountriesByID(@PathVariable Integer id){
		return service.getById(id);
	}
	
}
