package com.simeru.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.stereotype.Controller;

@Controller
public class Router {

	@GetMapping("index")
//	@ResponseBody
	public String home() 
	{
		return "index";
	}
	
	@GetMapping("capitals-quiz")
	public String capitalQuiz() 
	{
		return "capitals-quiz";
	}
	
	@GetMapping("flags-quiz")
	public String flagsQuiz() 
	{
		return "flags-quiz";
	}
	
}
