package com.simeru.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.simeru.entities.Country;

public interface CountryDAO extends JpaRepository<Country, Integer>{

		Optional<Country> findById(Integer id);
		List<Country> findByCountry(String country);
		List<Country> findByCapital(String capital);
		List<Country> findByRegion(String region);
		
		@Query(value = "select distinct(region) as region from countries", nativeQuery = true)
		List<Country> findByRegionDistinct();
}
