let boxContainer = document.querySelector("#boxContainer");
let question = document.querySelector("#question");
let pointsCounter = 0;
let questionsLeft = 0;
let start = 0;

function generaQuiz()
{
    if (start = 0)
    {
        localStorage.setItem("start",1);
        start = 1;
        location.reload();
    }

    const URL = "http://localhost:9080/api/countries/medium";
    fetch(URL)
        .then(response => {
            return response.json();
        })
        .then(data => {
            data.forEach(country => {
                boxContainer.appendChild(createButton(country));
                console.log(country);
                return country;});

                let pickedCountry = data[Math.floor(Math.random()*data.length)];
                
                createQuestion(pickedCountry);
                
                let rispostaGiusta = [];
                rispostaGiusta.push(pickedCountry);
                rispostaGiusta.forEach(element => {
                    let risposta = element.capital;
                    console.log(element.capital);
                });

                localStorage.setItem("rightAnswer", pickedCountry.capital)
        })
}

function createButton(country){
    let button = document.createElement("button");
    button.innerHTML = `
            <p>${country.capital}</p>
    `;
    button.addEventListener("click", function(){
        localStorage.setItem("capitalChoice", country.capital);
        responseCheck(country.capital);
    })
    return button;
}

function createQuestion(country){
    question.innerHTML = `La capitale del ${country.country} è...`
}

function responseCheck(){
    let pointsToJSON;
    let questionsLeftJSON;
    pointsCounter = localStorage.getItem("points");
    questionsLeft = localStorage.getItem("questionsLeft");

    if(localStorage.getItem("capitalChoice") == localStorage.getItem("rightAnswer"))
    {
        alert("RISPOSTA ESATTA");
        ++pointsCounter;
    }
    else
    {
        alert("RISPOSTA ERRATA");
        --pointsCounter;
    }
    ++questionsLeft;
    questionsLeftJSON = JSON.stringify(questionsLeft);
    localStorage.setItem("questionsLeft", questionsLeftJSON);
    pointsToJSON = JSON.stringify(pointsCounter);
    localStorage.setItem("points", pointsToJSON);

    if(localStorage.getItem("questionsLeft") == 10)
    {
        let punteggio = localStorage.getItem("points");
        if(punteggio<0)
        {
            punteggio = 0
        }
        alert(`Il gioco è finito hai totalizzato ${punteggio} punti!`);
        localStorage.clear();
    }
    location.reload();
}

window.addEventListener("DOMContentLoaded", generaQuiz);
