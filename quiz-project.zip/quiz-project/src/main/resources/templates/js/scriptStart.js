localStorage.clear();

let btnCapitalEasy = document.querySelector("#easy");
let btnCapitalMedium = document.querySelector("#medium");
let btnCapitalHard = document.querySelector("#hard");
let btnFlagsGame = document.querySelector("#btnFlags");

const URLCAPITALSEASY = "./capitals-quiz-easy.html";
const URLCAPITALSMEDIUM = "./capitals-quiz-medium.html";
const URLCAPITALSHARD = "./capitals-quiz-hard.html";
const URLFLAGS = "./flags-quiz.html";

function goCapitalEasy(){
    window.location.href = URLCAPITALSEASY;
}

function goCapitalMedium(){
    window.location.href = URLCAPITALSMEDIUM;
}

function goCapitalHard(){
    window.location.href = URLCAPITALSHARD;
}

btnCapitalsGameEasy = btnCapitalEasy.addEventListener("click", goCapitalEasy);
btnCapitalsGameMedium = btnCapitalMedium.addEventListener("click", goCapitalMedium);
btnCapitalsGameHard = btnCapitalHard.addEventListener("click", goCapitalHard);
btnFlagsGame = document.addEventListener("click");