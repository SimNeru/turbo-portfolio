package com.simeru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
