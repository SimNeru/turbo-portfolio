/* 
* Costraint aggiunge un un vincolo (primary key già un esempio o unique)
* Foreign Key (id) Reference nomeTabellaRiferimento(id)
* ON DELETE NO ACTION
* ON UPDATE NO ACTION
*
* AL POSTO DI NO ACTION
* CASCADE, la modifica del record padre cancella o aggiorna le righe figlie
* SET NULL, invece di cancellare le righe la tabella figlia applica il null (se è un campo nullable)
* NO ACTION, se provassi a cancellare una riga l'operazione verrebbe bloccata
*/
use courses;

-- INNODB è l'unico referenziale, possono esistere engine che non richiedono integrità referenziale
-- NO ACTION di default
Alter table corsi
add constraint fk_corsi_docenti
foreign key (docente_id) references docenti(id);

show create table corsi;

select * from docenti;
-- Non è possibile eliminare la tabella padre da cui è derivata la foregn key
delete from docenti where id = 1;
-- se elimino prima i record figli poi potrei eliminare la padre
delete from corsi where docente_id = 1;

-- CASCADE
-- quindi prima dobbiamo eliminare la chiave esterna prima di alterarla
alter table corsi drop foreign key fk_corsi_docenti; -- rimuove il vincolo da foreign key

Alter table corsi
add constraint fk_corsi_docenti
foreign key (docente_id) references docenti(id)
ON UPDATE CASCADE
ON DELETE CASCADE;

select * from corsi;
delete from docenti where id = 5;

-- SET NULL
-- verificare se la chiave esterna è un nullable
desc corsi;
alter table corsi drop foreign key fk_corsi_docenti;

alter table corsi
add constraint fk_corsi_docenti
foreign key (docente_id) references docenti(id)
ON UPDATE SET NULL
ON DELETE SET NULL;

select * from corsi;
delete from docenti where id = 2;

-- prima va inserito il docente con un nuovo id di riferimento altrimenti non puoi assegnare un dato non presente
update corsi set docente_id = 2
where titolo = 'basi di dati';

-- queries per inserire le foreign key esterne
-- RAPPORTO PADRE FIGLIA DALL'ESTERNO VERSO L'INTERNO

Alter table corsi
add constraint fk_corsi_docenti
foreign key (docente_id) references docenti(id);

-- padre CORSI | ID figlia ISCRIZIONI | CORSO_ID
Alter table iscrizioni
add constraint fk_iscrizioni_corsi
foreign key (corso_id) references corsi(id);

-- padre STUDENTE | ID figlia ISCRIZIONI | STUDENTI_ID
Alter table iscrizioni
add constraint fk_iscrizioni_studenti
foreign key (studente_id) references studenti(id);

-- FIX CONSISTENZA DEL DATO, NELLA TABELLA iscrizioni ERANO PRESENTI DEGLI ID CHE NON ERANO PRESENTI NEI CORSI
-- NEI CORSI ERANO PRESENTI 
alter table iscrizioni
drop foreign key fk_iscrizioni_corsi;
alter table iscrizioni
drop foreign key fk_iscrizioni_studenti;

select * from iscrizioni; -- 1,2,3,4,5
select * from corsi; -- 1,2,3,6,7,8,9

delete from iscrizioni
where corso_id in (4);