-- IN, NOT IN
select * from studenti
where provincia = 'mi' or provincia = 'cn' or provincia = 'al' or provincia = 'no';

-- query più breve semplificata che include i values riportati tra le parentesi
select * from studenti
where provincia in('mi','cn','al','no')
order by provincia
limit 10;

-- query esclude nel risultato i record con i values indicati tra parentesi
select * from studenti
where provincia not in('mi','cn','al','no');

-- between, not between
select * from studenti
where data_di_nascita between '1985-01-01' and '1994-12-31'
order by data_di_nascita;

select * from studenti
where data_di_nascita <= '1985-01-01' or data_di_nascita >= '1994-12-31'
order by data_di_nascita;

-- is null, is not null
select cognome, genere from studenti where genere is not null;
update studenti set citta = null where studente_id = 1;
select cognome, citta from studenti where citta is null;

-- like, not like
select * from studenti where cognome like 'v%'
order by cognome;

select * from studenti where nome like '%a' and genere like 'm'
order by nome;

select * from studenti where indirizzo like 'via%'
order by indirizzo;

select * from studenti where indirizzo like '%gmail.com'
order by indirizzo;

-- qualunque singolo carattere e la seconda a
select * from studenti where nome like '_a%'
order by nome;

-- _ indica anche un limite di characters del record che voglio ottenere
select * from studenti where nome like '________'
order by nome;

-- espressioni regolari, regex ha più simboli e consente ricerche più complesse
-- per vedere tutti i nomi che iniziano si usa ^ seguito dalla sequenza char interessata
select * from studenti where nome regexp '^mar';

-- $ indica i caratteri con cui deve finire la sequenza di chars
select * from studenti where nome regexp 'co$';

-- (pipe) | pattern per indicare un range di char contenuti (una sora di or)
select * from studenti where nome regexp '^mar|ara|co$';

-- combina ciascuna carattere incluso tra le parentesi quadre con il carattere contenuto esternamente (ma o ca o pa)
select * from studenti where nome regexp '[mcp]a';
-- $ indica quello con cui vanno a finire
select * from studenti where nome regexp 'l[ao]$';
-- - per indicare un range di valori da cui iniziano i record
select nome from studenti where nome regexp '^[a-m]'
order by nome;

-- operatori matematici
select 6 * 2;

-- per vedere il prezzo con un'operazione associata, fattibile anche tra più colonne
select titolo, prezzo, prezzo * 1.10
from libro;

-- colonne generate virtuali o persistenti, colonne aggiungibili alle tabelle
-- che consentono di creare una colonna che effettua un calcolo
alter table libro 
add prezzo_iva decimal (6,2) as (prezzo * 1.10) stored
after prezzo;
desc libro;
select * from libro;

-- in questo momento lo calcola ogni volta richiamato
alter table studenti
add nomeCompleto varchar(91) as (concat(nome,' ',cognome))
after cognome;
select nomeCompleto from studenti;
select * from studenti where nomeCompleto = 'franco rossi';
alter table studenti drop nomeCompleto;

-- in questo momento lo sta leggendo il record dalla tabella
alter table studenti
add nomeCompleto varchar(91) as (concat(nome,' ',cognome)) stored
after cognome;
select nomeCompleto from studenti;

