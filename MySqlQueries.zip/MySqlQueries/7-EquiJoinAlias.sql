select cognome, nome, titolo
from corsi, docenti
where docenti.id = corsi.docente_id;

select cognome, nome, titolo
from studenti, corsi, iscrizioni
where studenti.id = iscrizioni.studente_id 
and corsi.id = iscrizioni.corso_id
order by cognome, nome;

-- ALIAS
-- per le colonne
use goal2024;
select cognome as baba, data_nascita as `data di nascita` -- alt+9+6 apici versi
from studenti
order by data_nascita asc;

-- per tabelle
select s.cognome, s.nome, c.titolo -- da indicare con l'alias altrimenti non riconossce
from studenti s, corsi c, iscrizioni i -- le query iniziano dalla selezione tabelle
where s.id = i.studente_id 
and c.id = i.corso_id
order by cognome, nome;