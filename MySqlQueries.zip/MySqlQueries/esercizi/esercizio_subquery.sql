-- SUBQUERY
-- Scrivete le query richieste usando le subquery
-- RICORDATEVI che dovete conoscere come sono organizzati i dati per capire dove andare a prenderli

-- DB libri
-- 01) selezionate titolo, prezzo dei libri editi da "Einaudi"
select titolo, prezzo
from libri l
where l.editore_id = (
select editore_id
from editori e
where e.nome = "Einaudi");

-- DB corsi
-- 02) contate gli studenti non iscritti ad alcun corso
select count(s.studente_id) `tot studenti non inscritti`
from studenti s
where s.studente_id not in 
(select i.studente_id
from iscrizioni i);

-- 03) cancella l'iscrizione di "rossi franco"
-- al corso "Basi di dati"
delete from iscrizioni i 
where i.studente_id = (select s.studente_id from studenti s where s.nome = "franco" and s.cognome = "rossi") and
i.corso_id = (select c.corso_id from corsi c where c.titolo = "Basi di dati");

-- DB gestionale
-- 04) Selezionate nome, cognome, ruolo degli impiegati che lavorano nella città di Milano
select nome, cognome, ruolo
from impiegati i
where i.id_ufficio = any
( select id_ufficio from uffici u where u.citta = "Milano");

-- 05) Selezionate cognome, nome, email del cliente che ha eseguito il primo ordine
-- attenzione il primo ordine NON ha necessariamente id = 1
-- aiuto: join + subquery oppure 2 subquery nidificate in query princiaple
select cognome, nome, email 
from clienti c
where c.id_cliente = 
(select o.id_cliente from ordini o order by o.data_ordine asc limit 1);

-- 06) inserite un ordine di 10 monitor per il cliente "Bruni Carlo"
-- con data di oggi, stato di consegna: "da spedire"
-- dovete scrivere due query
-- inserite prima record in tabella ordine
-- inserite il dettaglio nella tabella ordini_dettaglio
-- ricordatevi delle funzione last_insert_id()
INSERT INTO ordini (ordini.id_cliente, ordini.data_ordine, ordini.stato_ordine)
values(
		(select c.id_cliente from clienti c where c.nome = "Carlo" and c.cognome="Bruni"),
		current_timestamp(),
        "da spedire"
);
INSERT INTO ordini_dettaglio (ordini_dettaglio.id_articolo, ordini_dettaglio.id_ordine, quantita, prezzo)
VALUES(
		(select i.id_articolo from articoli i where i.descrizione = "monitor"),
        (last_insert_id()), 
		10,
		(select i.prezzo from articoli i where i.descrizione = "monitor"));

-- DB Libri
-- 07) selezionate il quantitativo massimo di libri che abiamo a catalogo di un editore
select max(all_editori) `quantitativo massimo`
from (select count(*) as all_editori
from libri
group by editore_id) as tbl;
