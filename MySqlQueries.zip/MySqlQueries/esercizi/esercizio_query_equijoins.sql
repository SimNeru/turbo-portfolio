/* 1
Seleziona cognome, nome, email dei docenti
e titolo corso che insegnano
e ordina per cognome e nome
*/

select d.cognome, d.nome, d.email, c.titolo
from docenti as d, corsi as c
where d.id = c.docente_id
order by d.cognome, d.nome;

/* 2
Seleziona cognome, nome, email dei docenti
e titolo corso che costa meno di 200€(esclusi)
e ordina per cognome e nome
*/

select d.cognome, d.nome, d.email, c.titolo
from docenti as d, corsi as c
where c.prezzo < 200 and d.id = c.docente_id
order by d.cognome, d.nome;

/* 3
Seleziona cognome, nome, email del docente
che insegna nel corso HTML
*/

select d.cognome, d.nome, d.email
from docenti as d, corsi as c
where c.titolo = "HTML" and d.id = c.docente_id;

/* 4
Seleziona titolo corso/i insegnati dal docente il cui cognome è Verdi
e ordina per titolo corsi
*/

select c.titolo
from docenti as d, corsi as c
where d.cognome = "Verdi" and d.id = c.docente_id
order by c.titolo;

/* 5
Seleziona cognome, nome, email del/dei docente/i
che insegnano nei corsi il cui titolo comincia per 'Introduzione'
e ordina per titolo, cognome e nome
*/

select d.cognome, d.nome, d.email
from docenti as d, corsi as c
where c.titolo like "introduzione%" and d.id = c.docente_id
order by c.titolo, d.cognome, d.nome;

/* 6
Seleziona cognome, nome, email, degli studenti 
e titolo del corso a cui sono iscritti
e ordina per cognome e nome
*/

select s.cognome, s.nome, s.email, c.titolo
from studenti as s, corsi as c, iscrizioni as i
where s.id = i.studente_id and c.id = i.corso_id
order by s.cognome, s.nome;

/* 7
Seleziona cognome, nome, email, degli studenti FEMMINA
e titolo corso a cui sono iscritte
e ordina per cognome e nome
*/

select s.cognome, s.nome, s.email, c.titolo
from studenti as s, corsi as c, iscrizioni as i
where s.genere = 'f' and s.id = i.studente_id and c.id = i.corso_id
order by s.cognome, s.nome;

/* 8
Seleziona cognome, nome, email, degli studenti
iscritti al corso di Java
e ordina per cognome e nome
*/

select s.cognome, s.nome, s.email
from studenti as s, corsi as c, iscrizioni as i
where c.titolo = 'Java' and s.id = i.studente_id and c.id = i.corso_id
order by s.cognome, s.nome;

/* 9
Seleziona cognome, nome, email, degli studenti MASCHI
iscritti al corso di Basi di dati
e ordina per cognome e nome
*/

select s.cognome, s.nome, s.email
from studenti as s, corsi as c, iscrizioni as i
where s.genere = 'm' and c.titolo = 'basi di dati' and s.id = i.studente_id and c.id = i.corso_id
order by s.cognome, s.nome;

/* 10
Seleziona cognome, nome, email, degli studenti
iscritti a corsi per i quali hanno pagato più di 200€(compresi)
e ordina per cognome e nome
*/

select s.cognome, s.nome, s.email
from studenti as s, corsi as c, iscrizioni as i
where c.prezzo >= 200 and s.id = i.studente_id and c.id = i.corso_id
order by s.cognome, s.nome;