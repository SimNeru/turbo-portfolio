-- 1) contate il numero di libri editi da mondadori
select count(*) libri_mondadori
from libri l
join editori e
on l.editore_id = e.editore_id
where e.nome = "Mondadori";

-- 2) calcolate il valore del catalogo libri
select sum(libri.prezzo) totale
from libri;

-- 3) calcolate età media degli studenti, restituendo un valore intero
select round(avg(eta)) media_eta_studenti
from studenti;

-- 4) seleziona gli studenti e l'email creando un attributo in cui rappresentate il nome completo
-- es 'Marco Rossi', 'marco_rossi@gmail.com'
select concat(nome, ' ', cognome) nome_completo, email
from studenti;

-- 5) sostituite nella tabella studenti gli indirizzi contenenti 'Corso '  con 'Viale '
-- usare funzione REPLACE, attenzione che è case sensitive: 'viale' è diverso da 'Viale'
select studenti.indirizzo,
replace (lower(indirizzo), 'corso', 'Viale') conversione
from studenti 
order by studenti.indirizzo desc;

-- 6) selezionare nome,cognome,email, data_nascita degli studenti mostrando della data di nascita solo l'anno
select nome, cognome, email, year(data_nascita) anno
from studenti
order by anno desc;

-- 7) selezionare nome,cognome,email, data_nascita degli studenti mostrando la data di nascita nel formato italiano
select nome, cognome, email, date_format(data_nascita, '%d/%m/%Y') `data_ita`
from studenti
order by data_nascita desc;

-- 8) selezionate cognome, nome  degli autori e indicate se l'autore è 'Italiano' o 'Straniero'. Usare funzione if 
select cognome, nome, if(a.nazionalita = 'it', 'Italiana', 'Straniera') nazionalità
from autori a
order by cognome, nome;

/*
-- 9)
inserite nella tabella articolo, l'articolo seguente:
descrizione: Canon 7d
specifiche: marca: canon, modello: 7d, schermo: lcd, peso: 1.5 kg, sensore: CMOS, rapporto: 3:2, fullframe: no, uscite: hdmi mini, mini jack stero
*/
insert into articoli(descrizione, specifiche) 
values (
		'Canon 7d',
        json_object(
			"marca","canon",
            "modello","7d",
            "schermo","lcd",
            "pesoKg","1.5",
            "sensore","CMOS",
            "rapporto","3:2",
            "fullframe", "no",
            "uscite",json_array('hdmi mini', 'mini jack stereo')
        )
);
select * from articoli;

-- 10) selezionate dalla tabella articolo la marca, estraendola dalla colonna json
select descrizione, json_extract(specifiche, '$.marca') marca
from articoli;