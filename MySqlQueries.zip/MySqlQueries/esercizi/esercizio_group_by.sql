-- DB goal2024
-- 1) Contate gli studenti divisi per genere
-- la tabelle risultante mostrerà i seguenti attributi
-- Genere, Quanti
select genere, count(*) `Quanti`
from studenti
group by genere;

-- 2) Contate gli studenti divisi per genere solo della provincia di Alessandria
-- la tabelle risultante mostrerà i seguenti attributi
-- Genere, Quanti
select genere, count(*) `Quanti`
from studenti s
where lower(s.provincia) = 'al'
group by genere;

-- 3) Contate gli studenti divisi per regione
-- la tabelle risultante mostrerà i seguenti attributi
-- Regione, Quanti
select regione, count(*) `Quanti`
from studenti 
group by regione;

-- 4) Contate gli studenti divisi per regione e per genere
-- la tabelle risultante mostrerà i seguenti attributi
-- Regione, Genere, Quanti
select regione, genere, count(*) `Quanti`
from studenti 
group by regione, genere;

-- 5) Contate gli studenti divisi per regione e per genere mostrando anche i totali aggregati
-- ricordatevi della funzione grouping() e dell'istruzione with rollup
-- la tabelle risultante mostrerà i seguenti attributi, con le righe in più dei subtotali e del totale
-- Regione, Genere, Quanti
select 
        if (grouping(regione), 'tot regione', regione) provincia,
        if (grouping(genere), 'tot genere', genere) genere,
		count(*) `Quanti`
from studenti 
group by regione, genere with rollup;

-- 6) Contate gli impiegati divisi per ruolo
-- la tabelle risultante mostrerà i seguenti attributi
-- Ruolo, Quanti
select
	ruolo,
	count(*) `Quanti`
from impiegati
group by ruolo;

-- DB libro
-- 7) Contate gli autori divisi per nazionalità
-- la tabelle risultante mostrerà i seguenti attributi
-- Nazionalità, Quanti
select
	nazionalita,
	count(*) Quanti
from autori
group by nazionalita;

-- 8) Contate i libri per editore e il valore dei libri, ordinate per Editore
-- la tabelle risultante mostrerà i seguenti attributi
-- Editore, Quanti, Valore
select
	e.nome,
	count(*) `quanti`,
    sum(l.prezzo) `valore`
from
	editori e
join libri l
on e.editore_id = l.editore_id
group by e.nome
order by e.nome;
