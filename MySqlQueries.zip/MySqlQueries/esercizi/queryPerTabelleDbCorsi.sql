Create table docenti (
id int auto_increment primary key,
nome varchar(50) not null,
cognome varchar(50) not null,
email varchar(100) not null unique
);

Create table corsi (
id int auto_increment primary key,
titolo varchar(100) not null,
prezzo decimal (6,2),
docente_id int
);

Create table iscrizioni (
id int auto_increment primary key,
studente_id int not null,
corso_id int not null,
prezzo decimal (6,2),
data_isc timestamp null default current_timestamp
);
/*
Create table studenti (
id int primary key,
nome varchar(50),
cognome varchar(50) not null,
genere enum('m','f','nb'),
email varchar(100),
citta varchar()
data_isc date
)*/
create table studenti like goal2024.studenti;