-- lo scopo del raggruppamento è abbinato a delle funzioni di aggregrazione 
select distinct cognome from studenti;
select count(distinct cognome) from studenti;

-- GROUP BY
-- seleziono anche i cognomi che non si ripetono
select cognome from studenti
group by cognome;

select count(genere) maschi
from studenti 
where genere = 'm';
select count(genere) femmine
from studenti 
where genere = 'f';
-- operazione fattibile con group by

select genere, count(*) generi
from studenti 
group by genere;

select studenti.studente_id from studenti 
where genere is null;

select cognome, count(*) corsi_assegnati
from corsi c
join docenti d
using(docente_id)
group by cognome, c.docente_id;

select genere, count(*) tot, round(avg(eta)) età_media
from studenti
group by genere
order by età_media;

select titolo `Nome Corso`, 
count(*) `Iscritti`, 
sum(i.prezzo) `Valore Corso`
from corsi c
join iscrizioni i
using(corso_id)
group by i.corso_id
order by `Iscritti`;

select nome, 
count(*) as `Pubblicati`, 
sum(prezzo) `Valore catalogo`, 
round(avg(prezzo)) `Valore medio`,
min(prezzo) `Prezzo minimo`,
max(prezzo) `Prezzo massimo` 
from libri l
join editori e
on l.editore_id = e.editore_id
group by e.editore_id
order by `Pubblicati`;

-- group by potenizalità con le funzioni di aggregazione, con having possiamo intercettare l'alias 
select nome, 
count(*) as `Pubblicati`, 
sum(prezzo) `Valore catalogo`, 
round(avg(prezzo)) `Valore medio`,
min(prezzo) `Prezzo minimo`,
max(prezzo) `Prezzo massimo` 
from libri l
join editori e
on l.editore_id = e.editore_id
group by e.editore_id
having `Pubblicati` > 1
order by `Pubblicati`;

select provincia, genere, count(*) `tot`
from studenti
where provincia = 'AL'
group by provincia, genere
-- having `tot` > 1
order by provincia, genere;

-- esiste istruzione group by ... with rollup
-- produce una riga in più con il totale del gruppo
select provincia, count(*) `quanti`
from studenti
group by provincia with rollup
order by provincia;

-- aggiungera riga con la somma del subtotale di ciascuna provincia e una riga in più del gran totale
select provincia, genere,count(*) `quanti`
from studenti
group by provincia, genere with rollup;

-- funzione consente di sostituire quella riga in più con un'etichetta
-- group by ..- with rollup e grouping()
-- se la riga su cui insiste il grouping 0 o 1 se rappresenta un superaggrgato
select provincia, 
		grouping(provincia),
		count(*) `quanti`
from 
	studenti
group by provincia with rollup;
-- se usiamo funzione if posso inserire un'etichetta che mostra se è parte ti un totale o un subtotale
select provincia, 
		if (grouping(provincia), 'totale', provincia),
		count(*) `quanti`
from 
	studenti
group by provincia with rollup;

select
		if (grouping(provincia), 'totale', provincia) provincia,
        if (grouping(genere), 'tot genere', genere) genere,
		count(*) `quanti`
from 
	studenti
group by provincia, genere with rollup;
