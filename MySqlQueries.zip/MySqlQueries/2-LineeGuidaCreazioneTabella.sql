use goal2024;
-- nome, cognome, genere, indirizzo, citta, provincia, regione, email, data di nascita
/* */
create table if not exists Studenti(
	studente_id int auto_increment,
	nome varchar(30),
    cognome varchar(30) NOT NULL, /* indicato che non sia nullo */
    genere enum('f','m','nb'),
    indirizzo varchar(60),
    citta varchar(40),
    provincia varchar(2) default 'to', /* default inserisce in automatico*/
    regione varchar(20) default 'piemonte' comment 'inserisco regione di default', 
    email varchar(100) NOT NULL unique, /*indica che il record non può essere ripetuto*/
    data_di_nascita date,
    ins timestamp default current_timestamp on update current_timestamp, /* inserisce in autoomatico il'inserimento della data */
	primary key(studente_id) /* indice che memorizza posizioni sui nostri record */
);