-- numerosità deve essere uguale per quanto riguarda la numeriosità delle colonne richieste in una union
select capitale, stato
from europa
union
select capitale, stato
from americhe
union
select capitale, stato
from africa;

-- nel caso si dovesse selezionare un solo record o richiamare 
-- un order by sulle select sarà necessario usare le parentesi
(select capitale, stato
from europa
limit 1)
union 
(select capitale, stato
from americhe
limit 1)
union
(select capitale, stato
from africa
limit 1);

-- risultato nuove colonne dipende dalla definizione della prima query
select capitale as citta, stato as paese
from europa
union 
select capitale, stato
from americhe
union
select capitale, stato
from africa;

select * from goal2024.studenti;

-- generazione 
-- X < 1980-12-31
-- Millenials 1981-01-01 / 1995-12-31
-- Z > 1997-01-01
select cognome, data_nascita, 'X' Generazione
from studenti
where data_nascita <= '1980-12-31'
union 
select cognome, data_nascita, 'Millenials'
from studenti
where data_nascita between '1981-01-01' and '1995-12-31'
union
select cognome, data_nascita, 'Z'
from studenti
where data_nascita >= '1997-01-01'
order by data_nascita asc;
-- union all(include anche record duplicati) distinct(esclude le ripetizioni)

-- intersect, except (nuove istruzioni)
-- intersect: restituisce i valori in comune tra le tabelle (confronta partendo dalla prima nella seconda)
-- except: restituisce i valori che non sono in comune tra le tabelle
select docente_id
from corsi
intersect
select id
from docenti;

-- except 
select id
from docenti
except
select docente_id
from corsi;

-- sintassi JOIN più chiara lettura e altri vantaggi
-- INNER JOIN (o JOIN) sono equiJoin ma con una sintassi più stringata
select cognome, nome, titolo
from docenti, corsi
where docente_id = docenti.id;

select cognome, nome, titolo
from docenti
inner join corsi -- inner facoltativo
on docente_id = docenti.id;

-- LEFT JOIN (seleziona tutti i record della prima tabella e quelli che matchano con la seconda)
select cognome, nome, titolo
from docenti
left join corsi
on docente_id = docenti.id;

-- LEFT JOIN (seleziona tutti i record della prima tabella e quelli che non matchano con la seconda)
select cognome, nome, titolo
from docenti
left join corsi
on docente_id = docenti.id
where corsi.id is null;

-- RIGHT JOIN (seleziona tutti i record della seconda tabella e quelli che matchano con la seconda)
select cognome, nome, titolo
from docenti
right join corsi
on docente_id = docenti.id;

-- RIGHT JOIN (seleziona tutti i record della seconda tabella e quelli che non matchano con la seconda)
select cognome, nome, titolo
from docenti
right join corsi
on docente_id = docenti.id
where docenti.id is null;

-- FULL OUTER JOIN (UNION delle JOIN)
select cognome, nome, titolo
from docenti
left join corsi
on docente_id = docenti.id
union
select cognome, nome, titolo
from docenti
right join corsi
on docente_id = docenti.id;

-- FULL OUTER JOIN delle esclusioni
select cognome, nome, titolo
from docenti
left join corsi
on docente_id = docenti.id
where corsi.id is null
union
select cognome, nome, titolo
from docenti
right join corsi
on docente_id = docenti.id
where docenti.id is null;

-- estrarre i nomi, cognomi e corso a cui sono iscritti gli studenti
-- corsi, studenti, iscrizioni
select cognome, nome, titolo
from studenti s
join iscrizioni as i
on i.studente_id = s.id
join corsi c 
on c.id = i.corso_id
order by titolo;

select cognome, nome, titolo
from studenti s, corsi c, iscrizioni i
where i.studente_id = s.id and c.id = i.corso_id
order by titolo;

select cognome, nome, titolo
from studenti s
left join iscrizioni as i
on i.studente_id = s.id
left join corsi c 
on c.id = i.corso_id
order by titolo;

-- SELF JOIN
use goal2024;
select * from impiegati;
select i.cognome, i.nome, r.cognome
from impiegati i
join impiegati r
on i.id_responsabile = r.id;

select i.id_responsabile ,i.cognome, i.nome, r.cognome, i.id
from impiegati i
left join impiegati r
on i.id_responsabile = r.id;

/*INSERT INTO `impiegati`
VALUES (1,'Mario','Rossi','tecnico',NULL,2500.00),
(2,'Elena','Totti','amministrativo',NULL,2600.00),
(3,'Paola','Capra','venditore',NULL,2300.00),
(4,'Marco','Bianchi','amministrativo',2,1600.00),
(5,'Paolo','Verdi','amministrativo',2,1600.00),
(6,'Enrico','Marrone','venditore',3,1300.00),
(7,'Nicola','Testa','venditore',3,1300.00),
(8,'Franco','Barba','tecnico',1,1500.00),
(9,'Mauro','Barba','venditore',3,1300.00);*/

-- sintassi JOIN con USING
alter table docenti rename column id to docente_id;
alter table corsi rename column id to corso_id;
alter table studenti rename column id to studente_id;

-- USING(condizione di join) per tutte le tabelle coinvolte
select cognome, nome, titolo
from docenti
join corsi
using(docente_id);

-- NON EQUI-JOIN non si basano su operatori uguaglianza ma sugli altri
Create table if not exists generazioni( 
	id int auto_increment primary key,
	generazione varchar(20),
    anno_inizio date,
    anno_fine date
);

Insert into generazioni(generazione, anno_inizio, anno_fine) values
('boomers', '1946-01-01', '1964-12-31'),
('x', '1965-01-01', '1980-12-31'),
('millennials', '1981-01-01', '1996-12-31'),
('z', '1997-01-01', '2012-12-31');

select * from generazioni;

select cognome, nome, data_nascita, generazione
from studenti s
join generazioni g
on data_nascita between anno_inizio and anno_fine
order by data_nascita;

