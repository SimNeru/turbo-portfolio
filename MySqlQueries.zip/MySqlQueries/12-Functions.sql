-- avg(), non considera i valori nulli
select avg(prezzo) from corsi;

-- count() * conta le righe anche con i valori nulli
select count(*) from studenti;
update studenti set genere = null where studente_id = 1;
-- uno è null risulterà e non risulterà nel conteggio
select count(genere) from studenti;
-- distinct non aggiungerà al conteggio i cognomi che si ripetono
select count(distinct cognome) as conteggio from studenti;

-- sum()
select sum(prezzo) from corsi;
select sum(prezzo) from iscrizioni;

-- max(), min()
select max(prezzo) as max, min(prezzo) as min from corsi;

-- funzioni numeriche
-- floor(), ceiling() arrotondamento per difetto o eccesso
select * from libri;
select prezzo, floor(prezzo) as difetto, ceiling(prezzo) as eccesso from libri;

-- round() arrotondamento automatico da 0 a 4 (difetto), 5 9 (eccesso)
select prezzo, round(prezzo,1) as arrotondamento from libri;

-- composizione possibile tra le varie funzioni
select round(avg(prezzo),2) media from libri;

-- FUNZIONI STRINGA
-- lenght()
select titolo, length(titolo) lunghezza from libri;

-- concat(), concat_ws()
select concat(cognome,' ',nome) from autori;
-- consente definire un separatore all'inizio 
select concat_ws(' | ', cognome, nome, nazionalita) from autori;

-- substring, left(), right() 
-- dalla posizione 3 (inclusa) inizierà ad estrarre tutti i char sequenziali
select cognome, substring(cognome, 3) from studenti;
-- prende dalla posizione 1 i primi 3 caratteri
select cognome, substring(cognome,1,3) from studenti;
-- indica il quantitativo di char da sinistra(o destra) da riportare
select cognome, left(cognome,2), right(cognome,2) from studenti;
-- si possono combinare
select round(avg(length(concat(' ',cognome,nome))),2) as lunghezza from studenti;

-- FUNZIONI INFORMATIVE
-- last_insert_id()
select * from studenti;
insert into studenti(cognome, email) values ('pasquale','pasqu@mail.com');
insert into studenti(cognome, email) 
values 	('brutto','brutto@mail.com'),
		('biondo','biondo@mail.com');
-- indicherà l'id dell'ultimo record inserito, ma in caso di inserimento multiplo resituirà solo il primo
select last_insert_id();

-- replace
-- consente di sostituire in lettura ed aggiornamento i valori
-- replace prende in argomenti, la colonna, il valore e la sostituzione;
select email, replace(email, '.com', '.it') from studenti;
-- sopra solo in lettura, sotto aggiorna
update studenti set email = replace(email,'gmail.com','gmail.it');
update studenti set email = replace(email,'gmail.it','gmail.com');
select email from studenti;

-- FUNZIONI DATA E ORA
-- curdate() restituisce ora attuale
select curtime();
-- curdate() restituisce data attuale
select curdate();
-- now() restituisce data e ora attuali
select now();

insert into studenti(cognome,email,data_nascita)
values('cattivo','cattivissimo@icloud.com',curdate());
select * from studenti;

select data_nascita, year(data_nascita), month(data_nascita), day(data_nascita), dayofweek(data_nascita)
from studenti;

-- domenica viene considerato come primo (calendario inglese)
select dayofweek(curdate());
select dayname(curdate());
select monthname(curdate());
select hour(curtime());
select minute(curtime());
select second(curtime());

select @@lc_time_names;
set lc_time_names = 'it_IT';

-- DATE_FORMAT(), TIME_FORMAT()
-- richiede due parametri(colonna valore della data, pattern che costruisco in stringa)
select cognome, nome, date_format(data_nascita, '%d/%m/%Y') `data di nascita` from studenti
order by data_nascita;
select cognome, nome, date_format(data_nascita, '%d/%m dell\'anno %Y') `data di nascita` from studenti;

select time_format(curtime(),'%H:%i %p');

-- str_to_date() 
-- serve per raccogliere le date in un dato formato a seconda della località e poi convertirla
-- in formato americano per memorizzarlo nel db
select str_to_date('05/10/1969','%d/%m/%Y');
-- metterà in ordine la data da come input in output per il db da registrare 
insert into studenti(cognome,email,data_nascita)
values('villa','villa@gmail.com',str_to_date('05/10/1969','%d/%m/%Y'));

-- concateno i valori da diversi attributi
insert into studenti(cognome,email,data_nascita)
values('momo','momo@gmail.com',str_to_date(concat_ws('/','01','01','2003'),'%d/%m/%Y'));

-- restituisce l'ultimo record inserito in base all'ultimo id di riferimento
select * from studenti where studente_id = last_insert_id();

-- per modificare risultato date restituite
select adddate(curdate(), interval 5 day);
select subdate(curdate(),5);
select addtime(curtime(), 10);

select datediff('2024-05-24','2024-05-31');
select abs(datediff('2024-05-24','2024-05-31'));

select timestampadd(day,10,curdate());
select timestampdiff(year,'1969-10-05',curdate());

select cognome, 
	   nome, 
       timestampdiff(YEAR, 
       data_nascita, 
       CURDATE()) eta
from studenti
order by eta;

select * from studenti;
alter table studenti 
add column eta tinyint unsigned 
after data_nascita;
desc studenti;

update studenti 
set eta = timestampdiff(YEAR, data_nascita, curdate());

insert into studenti(cognome,email,data_nascita,eta)
values('biaggi','bg88@gmail.com','1988-08-08',timestampdiff(YEAR, data_nascita, curdate()));insert into studenti(cognome,email,data_nascita,eta)
values('biaggio','bg666@gmail.com',timestampdiff(YEAR, data_nascita, curdate()),'1988-08-08');

select * from studenti
where studenti.studente_id = 57;

select cognome, dayofyear(curdate()) - dayofyear(data_nascita) giorni
from studenti
having giorni between -31 and 0
order by giorni;

