show databases;
create database if not exists pippo;
drop database if exists pippo;

create user 'app_goal'@'localhost' identified by 'goal_2024!';

grant all
on goal2024.*
to 'app_goal'@'localhost';

-- utente: app_goal
-- host: localhost
-- psw: goal_2024!
-- dbname: goal2024