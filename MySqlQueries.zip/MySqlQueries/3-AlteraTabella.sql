alter table studenti rename studenti2; /* rinomina la tabella */
rename table studenti2 to studenti;

/* modifica tabella aggiungendo colonna */
alter table studenti 
add eta tinyint unsigned comment 'eta degli studenti'
after data_di_nascita;
desc studenti;

/* modifico il tipo di dato */
alter table studenti
modify nome varchar(40);
desc studenti;

/* modifico nome e data type */
alter table studenti
change nome nome2 varchar(30);
desc studenti;

/* rinominare solo il nome */
alter table studenti
rename column nome2 to nome;
desc studenti;

/* cancellare una colonna e altre istruzioni*/
alter table studenti
modify nome varchar(40),
drop eta;
desc studenti;

/* crea una copia identica a una di riferimento */
create table studenti_2 like studenti;
create table studenti_3 like studenti;
create table studenti_4 like studenti;
show tables;

/* cancellazione tabelle */
drop table studenti_2;
drop table studenti_3, studenti_4;
show tables;