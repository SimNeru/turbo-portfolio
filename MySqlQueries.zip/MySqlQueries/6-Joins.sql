select nome, cognome, email, titolo
from docenti, corsi
where docenti.id = corsi.docente_id
order by cognome;

select * from corsi;

-- cross join ogni record docente viene combinato con la tabella corsi
select nome, cognome, email, docenti.id, corsi.docente_id, titolo
from docenti, corsi;

select cognome, nome, titolo
from corsi, studenti, iscrizioni
where corsi.id = iscrizioni.corso_id 
and studenti.id = iscrizioni.studente_id
order by cognome, nome;