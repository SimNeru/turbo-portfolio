select * from corsi;
select * from docenti;

insert into corsi(titolo, prezzo, docente_id)
values ('CMS',100,50);

-- @@ (variabili di ambiente) 
select @@foreign_key_checks;

-- blocca il controllo delle foreign key, è un boolean 0 spento, 1 acceso
set foreign_key_checks = 0;
set foreign_key_checks = 1;

-- esiste la possibilità di una self FK
-- id_responsabile farà riferimento direttamente all'id primario
CREATE TABLE IF NOT exists impiegati (
id int auto_increment,
nome varchar(50),
cognome varchar(50),
ruolo varchar(50),
id_responsabile int,
stipendio decimal(6,2),
constraint sfk_impiegati
foreign key impiegati(id_responsabile) references impiegati(id)
on update cascade
on delete no action,
primary key(id));

INSERT INTO `impiegati`
VALUES (1,'Mario','Rossi','tecnico',NULL,2500.00),
(2,'Elena','Totti','amministrativo',NULL,2600.00),
(3,'Paola','Capra','venditore',NULL,2300.00),
(4,'Marco','Bianchi','amministrativo',2,1600.00),
(5,'Paolo','Verdi','amministrativo',2,1600.00),
(6,'Enrico','Marrone','venditore',3,1300.00),
(7,'Nicola','Testa','venditore',3,1300.00),
(8,'Franco','Barba','tecnico',1,1500.00),
(9,'Mauro','Barba','venditore',3,1300.00);

-- check funzionalità vincoli inseribili in una tabella per la verifica del dato anticipata
CREATE TABLE libri2 (
id int AUTO_INCREMENT,
titolo varchar(255),
prezzo decimal(6,2) NOT NULL constraint chk_prezzo_pagine CHECK (prezzo > 0),
pagine smallint unsigned CHECK (pagine > 0) /* CONSTRAINT chk_pagine CHECK (pagine > 0) */,
editore_id int,
PRIMARY KEY (id));

SHOW CREATE TABLE LIBRI2;
-- test verifica controlla prima i check costraint
INSERT INTO libri2 (titolo, pagine, prezzo, editore_id)
values('test2',0,0,1);