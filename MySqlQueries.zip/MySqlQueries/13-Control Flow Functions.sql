-- if
select cognome, nome, if(provincia = 'to', 'sede', 'fuori sede') sede from studenti;

-- case si basa su un valore
select provincia,
	case provincia
    when 'to' then 'torino'
    else 'fuori torino'
    end 'Provincia estesa'
from studenti;

-- case search sulla condizione di un'espressione
select titolo, prezzo,
case
	when prezzo < 5 then 'economico'
	when prezzo >= 5 and prezzo <= 10 then 'medio'
	when prezzo > 10 then 'caro'
end `Valutazione`
from libri
order by `Valutazione`;

-- '1980-12-31' X
-- '1981-01-01' 1996-12-31 Millenials
-- '1997-01-01' Z

select 
	cognome, nome,
	case
    when year(data_nascita) <= '1980' then 'X'
    when year(data_nascita) >= '1980' and year(data_nascita) <= '1996' then 'Millenials'
    when year(data_nascita) > '1997' then 'Z'
    end `Generazione`
from studenti
order by data_nascita desc;
