-- JSON function
create table if not exists articoli(
	id int auto_increment primary key,
	descrizione varchar(100),
    specifiche json
);
desc articoli;

insert into articoli(descrizione, specifiche)
values(
	'TV SAMSUNG 32" SMART TV',
	'{
		"marca" : "SAMSUNG",
        "pesoKg" : 5.12,
        "schermo" : "LCD",
        "pollici" : 32,
        "uscite" : ["HDMI", "USB"]
	}'
);

insert into articoli(descrizione, specifiche)
values(
	'TV Sony 32" SMART TV',
	json_object(
		"marca", "SONY",
        "pesoKg", 6.5,
        "schermo", "LED",
		"pollici", 32,
        "uscite", "HDMI"
    )
);

insert into articoli(descrizione, specifiche)
values(
	'TV Philips 55" SMART TV',
	json_object(
		"marca", "PHILIPS",
        "pesoKg", 9.5,
        "schermo", "LED",
		"pollici", 55,
        "uscite", json_array('HDMI','RCA','USB','SCART')
    )
);

-- estrazione dati specifici
select descrizione, json_extract(specifiche,'$.uscite', '$.pesoKg') from articoli;

select descrizione, 
json_extract(specifiche,'$.uscite', '$.pesoKg'),
json_extract(specifiche,'$.pesoKg') from articoli;

select descrizione, specifiche -> '$.uscite' from articoli;

select json_extract('[10,20,[30,40]]', '$[1]', '$[2][0]', '$[0]'); 
select json_extract('["a","b",["c","d"]]', '$[1]', '$[2][0]', '$[0]'); 

-- update json
update articoli
set specifiche = 
	json_set(
		specifiche,
        '$.marca','LG',
        '$.uscite', json_array('HDMI','SCART','S/PDIF'),
        '$.ingressi', json_array('ETHERNET','USB')
    )
where id = 1;

update articoli
set articoli.descrizione = 'TV LG 32" SMART TV'
where id = 1;

-- inserimento posizioni occupate, il jason_insert non worka
update articoli
set specifiche = 
	json_insert(
		specifiche,
        '$.uscite[3]', 'HDMI2'
    )
where id = 1;

-- funzione replace sostituisce solo valori esistenti
update articoli
set specifiche = json_replace(specifiche, '$.marca', 'Samsung')
where id = 1;

update articoli
set descrizione = 'TV Samsung 32" SMART TV' 
where id = 1;

update articoli
set specifiche = json_remove(specifiche, '$.uscite[3]')
where id = 1;

select JSON_PRETTY(specifiche) from articoli where id = 1;

select * from articoli;