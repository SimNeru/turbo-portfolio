show tables;
desc studenti; /*describe*/
show columns from studenti;
show full columns from studenti;
show create table studenti; /*mostra cosa l'engine che ha eseguito*/
show table status like 'studenti';