desc studenti;
/* auto increment aumenta anche in caso di valore errato prima di elaborare l'errore */
/* inserisco un record */
insert into studenti (cognome,email) /* ordine dei dati inseriti cambia corrispondenza importante */
values('nerucci','simone.nerucci@mail.com'); /* value/s non cambia*/
 
/* seleziono tutti i record presenti */
select * from studenti;
 
/* altro metodo insert */
insert into studenti
set cognome = 'pippo', email = 'pippo@gmail.com';

insert into studenti(email,cognome)
values
('bruni@mail.com', 'bruni'),
('rossi@mail.com', 'rossi'),
('verdi@mail.com', 'verdi');

/* questo metodo di inserimento vanno specificati tutti i valori */
insert into studenti
values(default, null, 'verdi', 'm', null, null, default, default, 'verdi2@mail.com', null, default);

/* metodo inserimento multiplo */
insert into studenti
values
(default, null, 'gialli', 'f', null, null, default, default, 'gialli@mail.com', null, default),
(default, null, 'arancioni', 'm', null, null, default, default, 'arancioni@mail.com', null, default);

/* visualizzo uno per uno (proiezione), visualizzerà solo le colonne interessate */
select
	studente_id,
	cognome,
    email
    from studenti;

/* posso duplicare i record in una tabella da un'altra */
create table amici(
id int auto_increment primary key,
nome varchar(30),
cognome varchar(50)
);

/* select produce una serie di record che verranno inseriti nella tabella amici */
insert into amici(cognome, nome)
select cognome, nome from studenti;
select * from amici;

/* fattibile anche direttamente alla creazione della tabella */
create table parenti(
id int auto_increment primary key,
nome varchar(30),
cognome varchar(50)
)
select cognome, nome from studenti;
select * from parenti;

/* clonabile tabella con la stessa struttura e gli stessi record (scopo backup)*/
create table studenti_bk like studenti;
insert into studenti_bk select * from studenti;
select * from studenti_bk;

/* stessa funzione del precedente ma con una struttura diversa dal precedente */
create table studenti_bk2 as select * from studenti;
desc studenti_bk2;

delete from studenti where studenti.studente_id = 7;